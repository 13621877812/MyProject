//
//  FNLoginManager.m
//  FNMine
//
//  Created by sun on 2018/4/27.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNLoginManager.h"
#import "FNTabbarViewController.h"
#import "AppDelegate.h"

@implementation UserInfo
@end


@interface FNLoginManager()
@property(nonatomic,copy)void(^loginSuccessBlock)(id x);
@property (nonatomic,assign,readwrite) BOOL loginSuccess;
@end

@implementation FNLoginManager


+(instancetype)shareInstance
{
    static FNLoginManager * loginManager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        loginManager = [[FNLoginManager alloc] init];
    });
    return loginManager;
}

-(instancetype)init
{
    if (self = [super init]) {
//        self.userInfo = [UserInfo new];
        @weakify(self);
//        [[RACObserve(self, userInfo.token) skip:1] subscribeNext:^(id  _Nullable x) {
//            @strongify(self);
//            self.loginSuccess = self.userInfo.token.length != 0;
////            self.loginSuccess ? [FNKeyChainManager saveUserInfo:self.userInfo] : [FNKeyChainManager deleteLoginInfo];
//        }];
    }
    return self;
}

-(void)handleAutoLoginAction
{

}

-(void)handleLogout:(UIViewController *)viewController
{
  
   

    if (viewController.navigationController) {
        [viewController.navigationController popToRootViewControllerAnimated:NO];
        FNTabbarViewController *tabbarViewController = (FNTabbarViewController *)[UIApplication sharedApplication].delegate.window.rootViewController;
        tabbarViewController.selectedIndex = FNTabbarSelectIndexProduct;
    }
}

-(FNNavigationController *)handleReLoginAction
{
  
    return [self loginRequestReturnBackHandle:nil];
}

/**
 *  通知登录成功，回调block
 */
-(void)handleLoginReturnBack:(UIViewController *)viewController
{
    if ([FNLoginManager shareInstance].loginSuccessBlock) {
        [FNLoginManager shareInstance].loginSuccessBlock(nil);
    }
    

        //直接扭转根window 的rootViewController
        [UIApplication sharedApplication].delegate.window.rootViewController = [FNTabbarViewController new];

    
   
}

/**
 *  登录成功回调
 */
//-(FNNavigationController *)loginRequestReturnBackHandle:(void (^)(id x))block
//{
//
//}

/**
 *  获取当前控制器
 */
-(UINavigationController *)currentViewController{
    
    FNTabbarViewController *tabbarViewController = (FNTabbarViewController *)[UIApplication sharedApplication].delegate.window.rootViewController;
    if (![tabbarViewController isKindOfClass:[FNTabbarViewController class]]) {
        return nil;
    }
    return tabbarViewController.selectedViewController;
}

//获取当前屏幕显示的viewcontroller
- (UIViewController *)getCurrentVC
{
    UIViewController *result = nil;
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows)
        {
            if (tmpWin.windowLevel == UIWindowLevelNormal)
            {
                window = tmpWin;
                break;
            }
        }
    }
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    if ([nextResponder isKindOfClass:[UIViewController class]]){
        result = nextResponder;
    }else if ([window respondsToSelector:@selector(rootViewController)] && window.rootViewController != nil){
        result = window.rootViewController;
    }
    
    return result;
}

-(UIViewController *)switchAppWindowRootViewController
{
    return nil;
}

-(void)rootLoginViewControllerCancelLogin
{
    [UIApplication sharedApplication].delegate.window.rootViewController = [FNTabbarViewController new];
}


//-(void)changeUserInfoSuccessThenReLoginWithUserName:(NSString *)userName
//{
//    [FNLoginManagerInstance handleLogout:self];
//    FNNavigationController *loginNav = [FNLoginManagerInstance handleReLoginAction];
//    UIViewController *viewController = loginNav.viewControllers.lastObject;
//    if ([viewController isKindOfClass:[FNLoginViewController class]]) {
//        [(FNLoginViewController *)viewController ]
//    }
//}

@end
