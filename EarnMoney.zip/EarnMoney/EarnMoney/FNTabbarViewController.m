//
//  FNTabbarViewController.m
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNTabbarViewController.h"
#import "FNNavigationController.h"
#import "FNLoginManager.h"


@interface FNTabbarViewController ()<UITabBarControllerDelegate>


@end

@implementation FNTabbarViewController
#pragma mark - life cycle
+ (void)initialize {
    [[UITabBar appearance] setTranslucent:NO];
//    [UITabBar appearance].barTintColor = [UIColor colorWithRed:0.95f green:0.95f blue:0.95f alpha:1.00f];
    
    UITabBarItem * item = [UITabBarItem appearance];
    
//   item.titlePositionAdjustment = UIOffsetMake(0, -5);
   
    NSMutableDictionary * normalAtts = [NSMutableDictionary dictionary];
    normalAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    normalAtts[NSForegroundColorAttributeName] = [UIColor whiteColor];
    [item setTitleTextAttributes:normalAtts forState:UIControlStateNormal];
    
    // 选中状态
    NSMutableDictionary *selectAtts = [NSMutableDictionary dictionary];
    selectAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    selectAtts[NSForegroundColorAttributeName] = FNColor(85, 58, 12);
    [item setTitleTextAttributes:selectAtts forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (NSClassFromString(@"FNHomeViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"FNHomeViewController") class] imageName:@"tabbar_home_unSel" selectedImageName:@"tabbar_home_Sel" title:@"首页"];
    }
    if (NSClassFromString(@"FNProductViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"FNProductViewController") class] imageName:@"tabbar_product_unSel" selectedImageName:@"tabbar_product_Sel" title:@"融资产品"];
    }
    if (NSClassFromString(@"FNBusinessViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"FNBusinessViewController") class] imageName:@"tabbar_bussiness_unSel" selectedImageName:@"tabbar_bussiness_Sel" title:@"我的业务"];
    }
    if (NSClassFromString(@"FNMineViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"FNMineViewController") class] imageName:@"tabbar_mine_unSel" selectedImageName:@"tabbar_mine_Sel" title:@"我的"];
    }
    
    self.delegate = self;
    
    UIImageView *tabbarImg=[[UIImageView alloc]initWithFrame:CGRectMake(0, FN_TABBER_BAR_HEIGHT-FN_TABBER_BAR_REAL_HEIGHT, FNScreenWidth,  FN_TABBER_BAR_REAL_HEIGHT)];
    tabbarImg.image=[UIImage imageNamed:@"fn_tabbar315"];
    [self.tabBar insertSubview:tabbarImg atIndex:0];
    [self.tabBar setBackgroundImage:[UIImage new]];
    [self.tabBar setShadowImage:[UIImage new]];
    
    if (!FNLoginManagerInstance.loginSuccess) {
        self.selectedIndex = FNTabbarSelectIndexProduct;
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:NO];
}

#pragma mark - private method
// 添加子控制器
- (FNNavigationController *)addChildViewControllerWithClass:(Class)class
                                                  imageName:(NSString *)imageName
                                          selectedImageName:(NSString *)selectedImageName
                                                      title:(NSString *)title {
    UIViewController *vc = [[class alloc]init];
    FNNavigationController *nav = [[FNNavigationController alloc] initWithRootViewController:vc];
    nav.tabBarItem.title = title;

    nav.tabBarItem.image = [[UIImage imageNamed:imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

    nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        nav.tabBarItem.imageInsets=UIEdgeInsetsMake(-5, 0, 5, 0);
    [self addChildViewController:nav];
    
    return nav;
}

#pragma mark - delegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    
    UIViewController *selectViewCtrl = [((FNNavigationController *)viewController).viewControllers firstObject];
    
    //未登录情况下，切换tabbar自动跳转至登录页面
    if ((self.selectedIndex == FNTabbarSelectIndexProduct)
        && (!FNLoginManagerInstance.loginSuccess)
        && (![selectViewCtrl isKindOfClass:NSClassFromString(@"FNProductViewController")])) {
        [FNLoginManagerInstance loginRequestReturnBackHandle:nil];
        return NO;
    }
    
//    if (self.selectedViewController == viewController) {
//        FCNavigationController *nav = (FCNavigationController *)viewController;
//        if ([nav.viewControllers.firstObject respondsToSelector:@selector(needRefreshTableViewData)]) {
//            [nav.viewControllers.firstObject needRefreshTableViewData];
//        }
//    }
    return YES;
}

@end
