//
//  FNTabbarViewController.m
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNTabbarViewController.h"
#import "FNNavigationController.h"
#import "FNLoginManager.h"


@interface FNTabbarViewController ()<UITabBarControllerDelegate>


@end

@implementation FNTabbarViewController
#pragma mark - life cycle
+ (void)initialize {
    [[UITabBar appearance] setTranslucent:NO];

    UITabBarItem * item = [UITabBarItem appearance];

    NSMutableDictionary * normalAtts = [NSMutableDictionary dictionary];
    normalAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    normalAtts[NSForegroundColorAttributeName] = GrayColor;
    [item setTitleTextAttributes:normalAtts forState:UIControlStateNormal];
    
    // 选中状态
    NSMutableDictionary *selectAtts = [NSMutableDictionary dictionary];
    selectAtts[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    selectAtts[NSForegroundColorAttributeName] = GoldenColor;
    [item setTitleTextAttributes:selectAtts forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (NSClassFromString(@"RecommendViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"RecommendViewController") class] imageName:@"recommend_S" selectedImageName:@"recommend_S" title:@"推荐"];
    }
    if (NSClassFromString(@"EarnViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"RecommendViewController") class] imageName:@"earn" selectedImageName:@"earn_S" title:@"赚钱方法"];
    }
    if (NSClassFromString(@"VideoViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"RecommendViewController") class] imageName:@"video" selectedImageName:@"video_S" title:@"视频"];
    }
    if (NSClassFromString(@"MineViewController")) {
        [self addChildViewControllerWithClass:[NSClassFromString(@"MineViewController") class] imageName:@"mine" selectedImageName:@"mine_S" title:@"我的"];
    }
    
    self.delegate = self;
    


}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:NO];
}

#pragma mark - private method
// 添加子控制器
- (FNNavigationController *)addChildViewControllerWithClass:(Class)class
                                                  imageName:(NSString *)imageName
                                          selectedImageName:(NSString *)selectedImageName
                                                      title:(NSString *)title {
    UIViewController *vc = [[class alloc]init];
    FNNavigationController *nav = [[FNNavigationController alloc] initWithRootViewController:vc];
    nav.tabBarItem.title = title;

    nav.tabBarItem.image = [UIImage imageNamed:imageName];

    nav.tabBarItem.selectedImage = [[UIImage imageNamed:selectedImageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [self addChildViewController:nav];
    
    return nav;
}



@end
