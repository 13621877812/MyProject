//
//  ZYLocationManager.h
//  ZYHainanLib
//
//  Created by sun on 16/8/1.
//  Copyright © 2016年 Haukit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>
#import "Singleton.h"
//#import <BaiduMapAPI_Base/BMKBaseComponent.h>
//#import <BaiduMapAPI_Location/BMKLocationComponent.h>
//#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>

@interface ZYLocationManager : NSObject
{
    NSTimer *locTimer;
    long long lastTime;
}

singleton_interface(ZYLocationManager)

//@property (nonatomic,strong)BMKLocationService* locService;


@property (nonatomic,assign) CLLocationDegrees latitude;
@property (nonatomic,assign) CLLocationDegrees longitude;

@property (nonatomic,assign) BOOL getLocationSuccess;

- (void)startUpdatingLocation;

- (void)sendLocationToServer;

+ (NSString *)distanceFromCurrentLocation:(CLLocation *)currentLocation ToBeforeLocation:(CLLocation *)beforeLocation;
@end
