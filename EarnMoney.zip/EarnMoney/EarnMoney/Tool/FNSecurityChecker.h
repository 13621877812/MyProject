//
//  SecurityChecker.h
//  HKCommonLib
//
//  Created by sun on 2018/1/12.
//  Copyright © 2018年 Haukit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNSecurityChecker : NSObject

//检测所有可能的风险
+(void)checkAllRisk;

//程序完整性检测
+(void)checkSignerIdentity;

//越狱提醒
+(void)jailbreakWarning;


@end
