//
//  NSData+MD5.h
//  UIImage+PDF example
//
//  Created by Nigel Barber on 25/06/2013.
//
//

#import <Foundation/Foundation.h>

@interface NSData (MD5)

- (NSString *)MD5;

@end
