//
//  SystemInfoUtils.m
//  DeviceInfoDemo
//
//  Created by sun on 2017/3/21.
//  Copyright © 2017年 Haukit. All rights reserved.
//

#import "AFSystemInfoUtils.h"
#import <UIKit/UIKit.h>
#import <AdSupport/AdSupport.h>
#import <CoreTelephony/CTCarrier.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import "ZYLocationManager.h"
//#import "AFNetworkReachabilityManager.h"
#import <sys/utsname.h>
#import <SystemConfiguration/CaptiveNetwork.h>
#include <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#include <netdb.h>
#import <SystemConfiguration/SCNetworkReachability.h>
#import "getgateway.h"
#import <arpa/inet.h>

#define LocationInfoKey @"LocationInfoKey"

#define Wi_Fi @"Wi-Fi"


#define TestSysUtils NSLog(@" appname:%@ \n getAppVersion:%@ \n getOsType:%@ \n getOsVersion:%@ \n getUDID:%@\n getIDFA:%@ \n getIDFV:%@ \n isJailbreak:%@ \n getNetType:%@ \n getDevice:%@ \n getHostName:%@ \n getWifiSSID:%@ \n getWifiMAC:%@ \n getTimeStamp:%@ \n getLastSystemStartTime:%@ \n getScreenResolution:%@ \n ",[self getAppName],[self getAppVersion],[self getOsType],[self getOsVersion],[self getUDID],[self getIDFA],[self getIDFV], [self isJailbreak],[self getNetType],[self getDevice],[self getHostName],[self getWifiSSID],[self getWifiMAC],[self getTimeStamp],[self getLastSystemStartTime],[self getScreenResolution]);

@implementation AFSystemInfoUtils


//App_Name	a1	接入App的包名	Package Name
+(NSString *)getAppName
{
    return [[NSBundle mainBundle] bundleIdentifier];
}

//App_Version	a2	接入App的版本号	—
+(NSString *)getAppVersion
{
    return [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
}

//Sdk_Version	a3	SDK的版本号	—
+(NSString *)getSdkVersion
{
    return [[UIDevice currentDevice] systemVersion];
}

//Os	a4	操作系统类型	—		需要
+(NSString *)getOsType
{
    return @"ios";
}

//Osv	a5	操作系统版本	—		需要
+(NSString *)getOsVersion
{
    return [[UIDevice currentDevice] systemVersion];
}

//Did	a6	设备唯一标识码（UDID）	—		需要
+(NSString *)getUDID
{
//    return [EMUDIDTools UDID];
    return nil;
}

//IDFA	a7	广告标示符			需要
+(NSString *)getIDFA
{
    NSString *idfa = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    if (idfa.length == 0) {
        return @"";
    }
    return idfa;
}

//IDFV	a8	Vendor标识符			需要
+(NSString *)getIDFV
{
    NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    if (idfv.length == 0) {
        return @"";
    }
    return idfv;
}

//Root	a9	是否已经越狱	1代表已越狱	需要
+(NSString *)isJailbreak
{
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://"]]) {
        NSLog(@"The device is jail broken!");
        return @"1";
    }
    return @"0";
}

//GPS	b1	经纬度信息	格式：经度,纬度	需要
+(CLLocation *)getLocation
{
    ZYLocationManager *locManager = [ZYLocationManager sharedZYLocationManager];
    if (!(locManager.latitude == 0 && locManager.longitude == 0)) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            NSDictionary *locaDic = @{@"latitude":[NSString stringWithFormat:@"%lf",locManager.latitude],
                                      @"longitude":[NSString stringWithFormat:@"%lf",locManager.longitude]};
            [[NSUserDefaults standardUserDefaults] setObject:locaDic forKey:LocationInfoKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
        });
        
        return [[CLLocation alloc]initWithLatitude:locManager.latitude longitude:locManager.longitude];
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:LocationInfoKey]) {
        NSDictionary *location = [defaults objectForKey:LocationInfoKey];
        return [[CLLocation alloc]initWithLatitude:[location[@"latitude"] doubleValue] longitude:[location[@"longitude"] doubleValue]];
    }else{
        return [[CLLocation alloc]initWithLatitude:0.0 longitude:0.0];
    }
}

+(NSString *)getLocationString
{
    return [NSString stringWithFormat:@"%f,%f",[AFSystemInfoUtils getLocation].coordinate.longitude,[AFSystemInfoUtils getLocation].coordinate.latitude];
}

//Net	b2	网络类型	Wi-Fi / 3G / 4G …
+(NSString *)getNetType
{
    NSString *strNetworkType = @"";
    
    //创建零地址，0.0.0.0的地址表示查询本机的网络连接状态
    struct sockaddr_storage zeroAddress;
    
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.ss_len = sizeof(zeroAddress);
    zeroAddress.ss_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    //获得连接的标志
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    //如果不能获取连接标志，则不能连接网络，直接返回
    if (!didRetrieveFlags)
    {
        return strNetworkType;
    }
    
    
    if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0)
    {
        // if target host is reachable and no connection is required
        // then we'll assume (for now) that your on Wi-Fi
        strNetworkType = Wi_Fi;
    }
    
    if (
        ((flags & kSCNetworkReachabilityFlagsConnectionOnDemand ) != 0) ||
        (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0
        )
    {
        // ... and the connection is on-demand (or on-traffic) if the
        // calling application is using the CFSocketStream or higher APIs
        if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0)
        {
            // ... and no [user] intervention is needed
            strNetworkType = Wi_Fi;
        }
    }
    
    if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
    {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
        {
            CTTelephonyNetworkInfo * info = [[CTTelephonyNetworkInfo alloc] init];
            NSString *currentRadioAccessTechnology = info.currentRadioAccessTechnology;
            
            if (currentRadioAccessTechnology)
            {
                if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyLTE])
                {
                    strNetworkType =  @"4G";
                }
                else if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyEdge] || [currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyGPRS])
                {
                    strNetworkType =  @"2G";
                }
                else
                {
                    strNetworkType =  @"3G";
                }
            }
        }
        else
        {
            if((flags & kSCNetworkReachabilityFlagsReachable) == kSCNetworkReachabilityFlagsReachable)
            {
                if ((flags & kSCNetworkReachabilityFlagsTransientConnection) == kSCNetworkReachabilityFlagsTransientConnection)
                {
                    if((flags & kSCNetworkReachabilityFlagsConnectionRequired) == kSCNetworkReachabilityFlagsConnectionRequired)
                    {
                        strNetworkType = @"2G";
                    }
                    else
                    {
                        strNetworkType = @"3G";
                    }
                }
            }
        }
    }
    
    
    if ([strNetworkType isEqualToString:@""]) {
        strNetworkType = @"WWAN";
    }

    return strNetworkType;
}


+(NSString *)getViaWWANType
{
//    CTRadioAccessTechnologyGPRS         //介于2G和3G之间，也叫2.5G ,过度技术
//    CTRadioAccessTechnologyEdge         //EDGE为GPRS到第三代移动通信的过渡，EDGE俗称2.75G
//    CTRadioAccessTechnologyWCDMA         //3G的网络制式
//    CTRadioAccessTechnologyHSDPA            //亦称为3.5G(3?G)
//    CTRadioAccessTechnologyHSUPA            //3G到4G的过度技术
//    CTRadioAccessTechnologyCDMA1x       //3G
//    CTRadioAccessTechnologyCDMAEVDORev0    //3G标准
//    CTRadioAccessTechnologyCDMAEVDORevA
//    CTRadioAccessTechnologyCDMAEVDORevB
//    CTRadioAccessTechnologyeHRPD        //电信使用的一种3G到4G的演进技术， 3.75G
//    CTRadioAccessTechnologyLTE          //接近4G
    CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];
    if ([info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyGPRS]
        || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyEdge]) {
        return @"2G";
    }else if([info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyWCDMA]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyHSDPA]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyHSUPA]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyCDMA1x]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyCDMAEVDORev0]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyCDMAEVDORevA]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyCDMAEVDORevB]
             || [info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyeHRPD]){
        return @"3G";
    }else if([info.currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyLTE]){
        return @"4G";
    }else{
        return @"CT_UnKnown";
    }
    
}

//Device	b3	设备型号	—		需要
+(NSString *)getDevice
{
//detail:http://www.cnblogs.com/xiaofeixiang/p/5100187.html
//    struct utsname systemInfo;
//    uname(&systemInfo);
//    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    return [[UIDevice currentDevice] model];
}

//HostName	b4	主机名	—		需要
+(NSString *)getHostName
{
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0)
    {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        //*/
        while(temp_addr != NULL)
        /*/
         int i=255;
         while((i--)>0)
         //*/
        {
            if(temp_addr->ifa_addr->sa_family == AF_INET)
            {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"])
                {
                    // Get NSString from C String //ifa_addr
                    //ifa->ifa_dstaddr is the broadcast address, which explains the "255's"
                    //                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_dstaddr)->sin_addr)];
                    
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    
                    //routerIP----192.168.1.255 广播地址
                    NSLog(@"broadcast address--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_dstaddr)->sin_addr)]);
                    //--192.168.1.106 本机地址
                    NSLog(@"local device ip--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)]);
                    //--255.255.255.0 子网掩码地址
                    NSLog(@"netmask--%@",[NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_netmask)->sin_addr)]);
                    //--en0 端口地址
                    NSLog(@"interface--%@",[NSString stringWithUTF8String:temp_addr->ifa_name]);
                    
                }
                
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    
    in_addr_t i =inet_addr([address cStringUsingEncoding:NSUTF8StringEncoding]);
    in_addr_t* x =&i;
    
    unsigned char *s=getdefaultgateway(x);
    NSString *ip=[NSString stringWithFormat:@"%d.%d.%d.%d",s[0],s[1],s[2],s[3]];
    free(s);
    return ip;
}

//Wifi_SSID	b5	连接wifi的名称		需要
+(NSString *)getWifiSSID
{
    NSDictionary *info = [self getCurrentNetworkInfo];

    NSString *ssid = info[@"SSID"];
    if (ssid.length > 0) {
        return ssid;
    }

    return @"";
}

//Wifi_MAC	b6	连接的wifi mac地址		需要
+(NSString *)getWifiMAC
{
    NSDictionary *info = [self getCurrentNetworkInfo];
    
    NSString *bssid = info[@"BSSID"];
    if (bssid.length > 0) {
        return bssid;
    }
    
    return @"";
}

+(NSDictionary *)getCurrentNetworkInfo
{
    NSArray* ifs = (__bridge_transfer id)CNCopySupportedInterfaces();
    NSDictionary *info = [NSDictionary dictionary];
    for (NSString* ifnam in ifs)
    {
        info = (__bridge id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        
        if (info && [info count])
            break;
    }
    return info;
}

//Time	t1	当前系统时间戳	精确到毫秒
+(NSString *)getTimeStamp
{
    NSTimeInterval time = [[NSDate date] timeIntervalSince1970]*1000;
    long long dTime = [[NSNumber numberWithDouble:time] longLongValue]; // 将double转为long long型
    return [NSString stringWithFormat:@"%llu",dTime]; // 输出long long型
}

//system_time	g5	系统上次启动时间点	精确到毫秒
+(NSString *)getLastSystemStartTime
{
    NSProcessInfo *info = [NSProcessInfo processInfo];
    
    NSLog(@"%f", info.systemUptime);
    NSDate *now = [NSDate date];
    NSTimeInterval interval = [now timeIntervalSince1970];
    NSLog(@"start time: %@", [self getDateStrFromTimeStep:interval - info.systemUptime]);
    return [self getDateStrFromTimeStep:interval - info.systemUptime];
}

+(NSString *)getDateStrFromTimeStep:(long long)timestep{
    
    NSDate *timestepDate = [NSDate dateWithTimeIntervalSince1970:timestep];
    //1377044552->2013-08-21 08:22:32
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    
    NSTimeZone* timeZone = [NSTimeZone systemTimeZone];
    [formatter setTimeZone:timeZone];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss:SSS"];
    return [formatter stringFromDate:timestepDate];
}



//screen	g6	屏幕分辨率信息
+(NSString *)getScreenResolution
{
    CGRect rect = [[UIScreen mainScreen] bounds];
    CGFloat scale = [[UIScreen mainScreen] scale];
    CGFloat width = rect.size.width * scale;
    CGFloat height = rect.size.height * scale;
    return [NSString stringWithFormat:@"%.0f*%.0f",width,height];
}

//carrier	g7	运营商信息	中国移动为0,中国联通为1,中国电信为2
+(NSString *)getPhoneCarrier
{
    
    CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [info subscriberCellularProvider];
    NSString * mcc = [carrier mobileCountryCode];
    NSString * mnc = [carrier mobileNetworkCode];
    if (mnc == nil || mnc.length <1 || [mnc isEqualToString:@"SIM Not Inserted"] ) {
        return @"Unknown";
    }else {
        if ([mcc isEqualToString:@"460"]) {
            NSInteger MNC = [mnc intValue];
            switch (MNC) {
                case 00:
                case 02:
                case 07:
                    return @"0";
                    break;
                    
                case 01:
                case 06:
                    return @"1";
                    break;
                    
                case 03:
                case 05:
                    return @"2";
                    break;
                    
                case 20: //铁通
                    return @"0";
                    break;
                    
                default:
                    break;
                    
            }
            
        }
    }
    return@"Unknown";

}

+(NSString *)isEmulator
{
#if TARGET_IPHONE_SIMULATOR
    return @"1";
#else
    return @"0";
#endif
}
    
@end
