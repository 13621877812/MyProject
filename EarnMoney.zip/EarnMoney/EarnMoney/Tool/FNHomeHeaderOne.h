//
//  ICRYHomeHeaderOne.h
//  ICRunYiECommerce

//  Created by JQ-MengKe on 16/11/22.
//  Copyright © 2016年 jianq. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^headerBlock)(NSInteger section);
@interface FNHomeHeaderOne : UIView
@property(nonatomic,copy)headerBlock HBlock;
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title WithFrame:(CGRect)frame;
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                    WithFrame:(CGRect)frame
                           WithSection:(NSInteger)headerSection
                                    withClick:(headerBlock)block;
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                 WithImageStr:(NSString*)string
                                    WithFrame:(CGRect)frame
                                  WithSection:(NSInteger)headerSection
                                    withClick:(headerBlock)block;
@property(nonatomic,copy) NSString *subImageTitle;  // 箭头图片
@property(nonatomic,strong) UILabel *subImageTitleLab;  // 箭头图片
@property (nonatomic,strong) UILabel* label;

+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                 titleColor:(UIColor *)titleColor
                                hideSepLine:(BOOL)hideSepLine
                                  WithFrame:(CGRect)frame
                                WithSection:(NSInteger)headerSection
                                  withClick:(headerBlock)block;

+(FNHomeHeaderOne*)creatSepTipsViewWithRightTitle:(NSString*)title
                                  frame:(CGRect)frame
                                  fontColor:(UIColor *)fontColor
                                   fontSize:(CGFloat)fontSize
                               sepViewColor:(UIColor *)sepViewColor;


@end
