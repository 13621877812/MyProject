//
//  ICRYHomeHeaderOne.m
//  ICRunYiECommerce
//
//  Created by JQ-MengKe on 16/11/22.
//  Copyright © 2016年 jianq. All rights reserved.
//

#import "FNHomeHeaderOne.h"

@interface FNHomeHeaderOne ()
@property(nonatomic,assign)NSInteger section;

@end

@implementation FNHomeHeaderOne
-(instancetype)initWithFrame:(CGRect)frame{
    self=[super initWithFrame:frame];
    if (self) {
//        UITapGestureRecognizer* gesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(headerCliked:)];
//        [self addGestureRecognizer:gesture];
    
    }
    return self;
}
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title WithFrame:(CGRect)frame
{
      FNHomeHeaderOne* header=[[FNHomeHeaderOne alloc]initWithFrame:frame];
    
    //创建子视图
    UIImageView* imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 115, 10)];
    imageView.center=CGPointMake(header.frame.size.width/2.0, header.frame.size.height/2.0);
    imageView.image=[UIImage imageNamed:@"home_cloud"];
    [header addSubview:imageView];
    
    UILabel *titleLab=[UILabel new];
    titleLab.frame=CGRectMake(0, 0, 100, header.bounds.size.height);
    titleLab.textColor=FNGrayColor(60);
    titleLab.font=[UIFont systemFontOfSize:13];
    titleLab.center=CGPointMake(header.bounds.size.width/2.0, header.bounds.size.height/2.0);
    titleLab.textAlignment=NSTextAlignmentCenter;
    titleLab.text=title;
    [header addSubview:titleLab];
    
    
    return header;
    
}
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                 WithImageStr:(NSString*)string
                                    WithFrame:(CGRect)frame
                                  WithSection:(NSInteger)headerSection
                                    withClick:(headerBlock)block{
    
    FNHomeHeaderOne* header=[[FNHomeHeaderOne alloc]initWithFrame:frame];
    header.backgroundColor=[UIColor whiteColor];
    header.section=headerSection;
//    header.userInteractionEnabled=YES;
    header.HBlock=block;
    //创建子视图
//    UIImageView* TitleImage=[[UIImageView alloc]initWithFrame:CGRectMake(16, header.height/2-12, 24, 24)];
//    TitleImage.contentMode=UIViewContentModeScaleToFill;
//    
//    TitleImage.image=[UIImage imageNamed:string];
    
    UIView *liftLine = [[UIView alloc]initWithFrame:CGRectMake(20, 5, 5, header.frame.size.height-10)];
    liftLine.backgroundColor = [UIColor blueColor];
    [header addSubview:liftLine];
    
    UILabel* label=[[UILabel alloc]initWithFrame:CGRectMake(liftLine.frame.origin.x+liftLine.frame.size.width+10, header.frame.size.height/2-10, 100, 20)];
    label.text=title;
    //    label.backgroundColor=[UIColor redColor];
    label.font=[UIFont systemFontOfSize:16];
    label.textColor=[UIColor blackColor];
    [header addSubview:label];
    UIImageView* imageView=[[UIImageView alloc]initWithFrame:CGRectMake(header.frame.size.width-27, header.center.y-7.5, 12, 17)];
//    imageView.image=[UIImage imageNamed:@"ICRY_next_arrow"];
    [header addSubview:imageView];
    UIView* Line=[[UIView alloc]initWithFrame:CGRectMake(0, header.frame.size.height-0.5, FNScreenWidth, 0.5)];
    Line.backgroundColor=[UIColor lightGrayColor];
    [header addSubview:Line];
    
    return header;
    
}
+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                    WithFrame:(CGRect)frame
                                  WithSection:(NSInteger)headerSection
                                    withClick:(headerBlock)block{
    return [self creatHeaderViewWithTitle:title titleColor:[UIColor blackColor] hideSepLine:NO WithFrame:frame WithSection:headerSection withClick:block];
    
}


+(FNHomeHeaderOne*)creatHeaderViewWithTitle:(NSString*)title
                                 titleColor:(UIColor *)titleColor
                                hideSepLine:(BOOL)hideSepLine
                                  WithFrame:(CGRect)frame
                                WithSection:(NSInteger)headerSection
                                  withClick:(headerBlock)block
{
    
    FNHomeHeaderOne* header=[[FNHomeHeaderOne alloc]initWithFrame:frame];
    header.backgroundColor=[UIColor whiteColor];
    header.section=headerSection;
    header.userInteractionEnabled=YES;
    header.HBlock=block;
    //创建子视图
    UIImageView* imageView=[[UIImageView alloc]initWithFrame:CGRectMake(6, 0, FNScreenWidth-6, 15)];
    imageView.center=CGPointMake(header.frame.size.width/2.0+3, header.frame.size.height/2.0);
    imageView.image=[UIImage imageNamed:@"home_tipBar"];
    [header addSubview:imageView];
    
    
    
    UILabel* label=[[UILabel alloc]initWithFrame:CGRectMake(50, 0, 100, header.bounds.size.height)];
    label.text=title;
    label.font=[UIFont systemFontOfSize:14];
    label.textColor = titleColor;
    [header addSubview:label];
    header.label = label;
    
    UIButton *moreBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    moreBtn.frame=CGRectMake(header.bounds.size.width-50, 0, 50, header.bounds.size.height);
    [moreBtn setTitle:@"   更多" forState:UIControlStateNormal];
    moreBtn.titleLabel.font=[UIFont systemFontOfSize:11];
    [moreBtn setTitleColor:FNMoreBtnGrayColor forState:UIControlStateNormal];
    [moreBtn addTarget:header action:@selector(headerCliked:) forControlEvents:UIControlEventTouchUpInside];
    
    if (!hideSepLine) {
        UIView *bottomLine=[UIView new];
        bottomLine.backgroundColor=FNGrayColor(210);
        bottomLine.frame=CGRectMake(0, header.bounds.size.height-1, header.bounds.size.width, 1);
        [header addSubview:bottomLine];
    }
    
    
    if (block) {
        imageView.image=[UIImage imageNamed:@"home_more_tipBar"];
        [header addSubview:moreBtn];
        [header removeFromSuperview];
    }
    
    return header;
}



+(FNHomeHeaderOne*)creatSepTipsViewWithRightTitle:(NSString*)title
                                            frame:(CGRect)frame
                                        fontColor:(UIColor *)fontColor
                                         fontSize:(CGFloat)fontSize
                                     sepViewColor:(UIColor *)sepViewColor
{
    
    FNHomeHeaderOne* header=[[FNHomeHeaderOne alloc]initWithFrame:frame];
    header.backgroundColor=[UIColor whiteColor];
    
    UIView *liftLine = [[UIView alloc]initWithFrame:CGRectMake(20, 10, 5, header.frame.size.height-20)];
    liftLine.backgroundColor = sepViewColor;
    [header addSubview:liftLine];
    
    UILabel* label=[[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(liftLine.frame)+10, header.frame.size.height/2-10, frame.size.width-CGRectGetMaxX(liftLine.frame)-10, 20)];
    label.text=title;
    label.font=[UIFont systemFontOfSize:fontSize];
    label.textColor=fontColor;
    [header addSubview:label];
    
    return header;
}

-(void)headerCliked:(UIButton *)btn
{
    
    
    if (self.HBlock) {
        self.HBlock(_section);
    }
    
}

- (void)setSubImageTitle:(NSString *)subImageTitle{
    _subImageTitle = subImageTitle;
    if (subImageTitle.length>0) {
        UIImageView *subImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:subImageTitle]];
        subImageView.frame = CGRectMake(self.frame.size.width-30, 0, 13, 13);
        subImageView.center =CGPointMake(subImageView.center.x, self.center.y);
        [self addSubview:subImageView];
        
        
    }
 
}

@end
