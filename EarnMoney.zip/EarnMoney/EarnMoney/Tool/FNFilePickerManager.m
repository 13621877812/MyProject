//
//  FNFilePickerManager.m
//  FNBase
//
//  Created by Eastman on 2018/10/31.
//  Copyright © 2018 FNCONN. All rights reserved.
//

#import "FNFilePickerManager.h"

#import "AuthorizationChecker.h"

#import "UIImage+Scale.h"

@interface FNFilePickerManager()<UIDocumentPickerDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>


@end

@implementation FNFilePickerManager

-(instancetype)init
{
    if (self = [super init]) {
        self.maxLength = 0;
    }
    return self;
}

/**
 图片选择器，默认弹出ActionSheet用户选择“相册，相机”
 
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)imagePickerFromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    return [self imagePickerFromPresentationController:presentationCtrl compressToMaxLength:0 success:success failure:failure];
}

/**
 图片选择器，默认弹出ActionSheet用户选择“相册，相机”
 
 @param presentationCtrl 弹出文件选择器的父控制器
 @param maxLength 压缩到最大值 eg：(压缩到2M，maxLength = 2000*1000)
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)imagePickerFromPresentationController:(UIViewController *)presentationCtrl compressToMaxLength:(NSUInteger)maxLength success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    FNFilePickerManager *pickerManager = [FNFilePickerManager new];
    pickerManager.presentationCtrl = presentationCtrl;
    pickerManager.maxLength = maxLength;
    
    UIAlertController *alertSelect = [UIAlertController alertControllerWithTitle:nil message:@"请选择" preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypeCamera presentationController:presentationCtrl success:success failure:failure];
    }];
    UIAlertAction *photo = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypePhotoLibrary presentationController:presentationCtrl success:success failure:failure];
    }];
    
    UIAlertAction *cancelAction=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertSelect addAction:camera];
    [alertSelect addAction:photo];
    [alertSelect addAction:cancelAction];
    
    [presentationCtrl presentViewController:alertSelect animated:YES completion:nil];
    
    return pickerManager;
}

/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”
 
 @param allowedUTIs 当用户选择Document时，所支持的文件类型UITIs
 @param mode UIDocumentPickerMode,default is UIDocumentPickerModeOpen
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerWithDocumentTypes:(NSArray <NSString *>*)allowedUTIs inMode:(UIDocumentPickerMode)mode fromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    return [self filePickerWithDocumentTypes:allowedUTIs inMode:mode compressToMaxLength:0 fromPresentationController:presentationCtrl success:success failure:failure];
}

/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”
 
 @param allowedUTIs 当用户选择Document时，所支持的文件类型UITIs
 @param mode UIDocumentPickerMode,default is UIDocumentPickerModeOpen
 @param maxLength 压缩到最大值 eg：(压缩到2M，maxLength = 2000*1000)
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerWithDocumentTypes:(NSArray <NSString *>* __nonnull)allowedUTIs inMode:(UIDocumentPickerMode)mode compressToMaxLength:(NSUInteger)maxLength fromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    FNFilePickerManager *pickerManager = [FNFilePickerManager new];
    pickerManager.presentationCtrl = presentationCtrl;
    pickerManager.maxLength = maxLength;
    
    UIAlertController *alertSelect = [UIAlertController alertControllerWithTitle:nil message:@"请选择" preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypeCamera presentationController:presentationCtrl success:success failure:failure];
    }];
    UIAlertAction *photo = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypePhotoLibrary presentationController:presentationCtrl success:success failure:failure];
    }];
    UIAlertAction *document = [UIAlertAction actionWithTitle:@"从文件选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (allowedUTIs) {
            pickerManager.documentPickerVC = [[FNDocumentPickerViewController alloc] initWithDocumentTypes:allowedUTIs inMode:mode?UIDocumentPickerModeOpen:mode];
            pickerManager.documentPickerVC.delegate = pickerManager;
            pickerManager.documentPickerVC.modalPresentationStyle = UIModalPresentationFormSheet;
        }
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypeDocument presentationController:presentationCtrl success:success failure:failure];
    }];
    UIAlertAction *cancelAction=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertSelect addAction:camera];
    [alertSelect addAction:photo];
    [alertSelect addAction:document];
    [alertSelect addAction:cancelAction];
    
    [presentationCtrl presentViewController:alertSelect animated:YES completion:nil];
    
    return pickerManager;
}

/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”
 
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerFromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    FNFilePickerManager *pickerManager = [FNFilePickerManager new];
    pickerManager.presentationCtrl = presentationCtrl;
    
    UIAlertController *alertSelect = [UIAlertController alertControllerWithTitle:nil message:@"请选择" preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *camera = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypeCamera presentationController:presentationCtrl success:success failure:failure];
    }];
    UIAlertAction *photo = [UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypePhotoLibrary presentationController:presentationCtrl success:success failure:failure];
//        [pickerManager filePickSourceFrom:FNFilePickerSourceTypePhotoLibrary presentationController:presentationCtrl success:^(id  _Nonnull data, NSURL * _Nonnull fileUrl, NSString * _Nonnull filePath) {
//            if (success) {
//                success(data,fileUrl,filePath);
//            }
//        } failure:^(NSError * _Nonnull error, NSString * _Nonnull errorMsg) {
//            if (failure) {
//                failure(error,errorMsg);
//            }
//        }];
    }];
    UIAlertAction *document = [UIAlertAction actionWithTitle:@"从文件选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self authorizationCheckerWithPickerManager:pickerManager pickSource:FNFilePickerSourceTypeDocument presentationController:presentationCtrl success:success failure:failure];
//        [pickerManager filePickSourceFrom:FNFilePickerSourceTypeDocument presentationController:presentationCtrl success:^(id  _Nonnull data, NSURL * _Nonnull fileUrl, NSString * _Nonnull filePath) {
//            if (success) {
//                success(data,fileUrl,filePath);
//            }
//        } failure:^(NSError * _Nonnull error, NSString * _Nonnull errorMsg) {
//            if (failure) {
//                failure(error,errorMsg);
//            }
//        }];
    }];
    UIAlertAction *cancelAction=[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertSelect addAction:camera];
    [alertSelect addAction:photo];
    [alertSelect addAction:document];
    [alertSelect addAction:cancelAction];
    
    [presentationCtrl presentViewController:alertSelect animated:YES completion:nil];
    
    return pickerManager;
}

+(void)authorizationCheckerWithPickerManager:(FNFilePickerManager *)pickerManager pickSource:(FNFilePickerSourceType)sourceType presentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    if (sourceType == FNFilePickerSourceTypeCamera) {
        [AuthorizationChecker cameraAuthorityCheckSuccess:^{
            [pickerManager filePickSourceFrom:sourceType presentationController:presentationCtrl success:success failure:failure];
        } cancel:^{
            
        }];
    }else if(sourceType == FNFilePickerSourceTypePhotoLibrary){
        [AuthorizationChecker albumAuthorityCheckSuccess:^{
            [pickerManager filePickSourceFrom:sourceType presentationController:presentationCtrl success:success failure:failure];
        } cancel:^{
            
        }];
    }else{
        [pickerManager filePickSourceFrom:sourceType presentationController:presentationCtrl success:success failure:failure];
    }
}

/**
 文件选择器
 
 @param sourceType 文件选择类型：相册，相机，文件
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 */
-(void)filePickSourceFrom:(FNFilePickerSourceType)sourceType presentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure
{
    self.success = success;
    self.failure = failure;
    self.presentationCtrl = presentationCtrl;
    if (sourceType == FNFilePickerSourceTypeDocument) {
        [presentationCtrl presentViewController:self.documentPickerVC animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
        }];
    }else{
        if (sourceType == FNFilePickerSourceTypeCamera) {
            self.imagePickerVC.sourceType = UIImagePickerControllerSourceTypeCamera;
        }else if(sourceType == FNFilePickerSourceTypePhotoLibrary){
            self.imagePickerVC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        }
        [presentationCtrl presentViewController:self.imagePickerVC animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
        }];
    }
}

#pragma mark - UIDocumentPickerDelegate
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    //获取授权申请权限
    BOOL fileUrlAuthozied = [url startAccessingSecurityScopedResource];
    if (fileUrlAuthozied) {
        //通过文件协调工具来得到新的文件地址，以此得到文件保护功能
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] init];
        NSError *error;
        
        [fileCoordinator coordinateReadingItemAtURL:url options:0 error:&error byAccessor:^(NSURL *newURL) {
            //读取文件
            NSString *fileName = [newURL lastPathComponent];
            NSError *error = nil;
            NSData *fileData = [NSData dataWithContentsOfURL:newURL options:NSDataReadingMappedIfSafe error:&error];
            if (error) {//读取出错
//                [FNEasyShowManager showHudWithMessage:@"文件读取出错"];
                if (self.failure) {
                    self.failure(error,@"文件读取出错");
                }
            } else {
                NSString *filePath;
                if (fileName.length != 0) {
                    //写入沙盒Documents
                    NSString *documentDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
                    NSString *fileDirectory = [documentDirectory stringByAppendingPathComponent:@"FilePicker"];
                    NSString *filePath = [fileDirectory stringByAppendingString:[NSString stringWithFormat:@"/%@",fileName]];
                    [[NSFileManager defaultManager] createDirectoryAtPath:fileDirectory withIntermediateDirectories:YES attributes:nil error:nil];
                    if ([fileData writeToFile:filePath atomically:YES]) {
                        
                    }
                }
                if ((self.maxLength != 0) && (fileData.length > self.maxLength) && (self.failure)) {
                    self.failure([NSError new], FileOutofLengthTips);
                }else if (self.success) {
                    self.success(fileData, newURL,filePath,[self fileTypeWithFileName:fileName]);
                }
            }
            [self.presentationCtrl dismissViewControllerAnimated:YES completion:^{
                [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
            }];
        }];
        [url stopAccessingSecurityScopedResource];
    } else {//授权失败
//        [FNEasyShowManager showHudWithMessage:@"文件获取授权失败"];
        if (self.failure) {
            self.failure([NSError new],@"文件获取授权失败");
        }
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }
}

#pragma mark --- imagePickerController  delegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    if (self.maxLength != 0) {
        NSData *imageData = [image compressWithMaxLength:self.maxLength];
        image = [UIImage imageWithData:imageData];
    }
    
//    NSURL *fileUrl;
//    if (@available(iOS 11.0, *)) {
//        fileUrl = [info objectForKey:UIImagePickerControllerPHAsset];
//    } else {
//        fileUrl = [[NSURL alloc] initWithString:[info objectForKey:UIImagePickerControllerReferenceURL]];
//    }
    NSURL *fileUrl = [info objectForKey:UIImagePickerControllerImageURL];
    
    if (self.success) {
        self.success(image, fileUrl, fileUrl.absoluteString, FNFileTypeImage);
    }
    
    [self.presentationCtrl dismissViewControllerAnimated:YES completion:^{
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
//    if (self.failure) {
//        self.failure(nil, @"取消了照片选择");
//    }
    [self.presentationCtrl dismissViewControllerAnimated:YES completion:^{
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    }];
}

#pragma mark --- private
-(FNFileType)fileTypeWithFileName:(NSString *)fileName
{
    NSArray *imageStrings = @[@"jpg",@"jpeg",@"png",@"bmp",@"3gpp"];
    NSArray *videoStrings = @[@"avi",@"mp4",@"rm",@"rmvb",@"mpeg",@"3gp",@"flv",@"wmv"];
    
    NSString *typeString = [[[fileName componentsSeparatedByString:@"."] lastObject] lowercaseString];
    if ([imageStrings containsObject:typeString] ) {
        return FNFileTypeImage;
    }else if ([typeString isEqualToString:@"pdf"]){
        return FNFileTypePdf;
    }else if ([typeString isEqualToString:@"xls"] || [typeString isEqualToString:@"xlsx"]){
        return FNFileTypeExcel;
    }else if ([typeString isEqualToString:@"ppt"] || [typeString isEqualToString:@"pptx"]){
        return FNFileTypePPT;
    }else if ([typeString isEqualToString:@"doc"] || [typeString isEqualToString:@"docx"]){
        return FNFileTypeWord;
    }else if ([videoStrings containsObject:typeString]){
        return FNFileTypeVideo;
    }else{
        return FNFileTypeUnknow;
    }
}

#pragma mark - getters and setters
//@"public.image", @"com.adobe.pdf", @"com.microsoft.excel.xls"
- (FNDocumentPickerViewController *)documentPickerVC
{
    if(!_documentPickerVC){
        _documentPickerVC = [[FNDocumentPickerViewController alloc]
                             initWithDocumentTypes:@[
                                                     @"com.microsoft.powerpoint.​ppt",
                                                     @"com.microsoft.word.doc",
                                                     @"com.microsoft.excel.xls",
                                                     @"com.microsoft.powerpoint.​pptx",
                                                     @"com.microsoft.word.docx",
                                                     @"com.microsoft.excel.xlsx",
                                                     @"public.avi",
                                                     @"public.3gpp",
                                                     @"public.mpeg-4",
                                                     @"com.compuserve.gif",
                                                     @"public.jpeg",
                                                     @"public.png",
                                                     @"public.image",
                                                     @"public.plain-text",
                                                     @"com.adobe.pdf"
                                                     ] inMode:UIDocumentPickerModeOpen];
        //设置代理
        _documentPickerVC.delegate = self;
        //设置模态弹出方式
        _documentPickerVC.modalPresentationStyle = UIModalPresentationFormSheet;
    }
    return _documentPickerVC;
}

- (FNImagePickerController *)imagePickerVC
{
    if(!_imagePickerVC){
        _imagePickerVC = [[FNImagePickerController alloc]init];
        _imagePickerVC.delegate = self;
    }
    return _imagePickerVC;
}

@end


/**
 * Revision History
 * ------------------------------------------------------------
 * Version       Date       Author      Note
 * ------------------------------------------------------------
 *  1.0.0     2018-10-31    fpm0311   fna2018Q40321
 */
