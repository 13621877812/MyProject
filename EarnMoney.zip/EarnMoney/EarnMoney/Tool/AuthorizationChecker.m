//
//  AuthorizationChecker.m
//  HKCommonLib
//
//  Created by sun on 2018/1/2.
//  Copyright © 2018年 Haukit. All rights reserved.
//

#import "AuthorizationChecker.h"
#import "AppDelegate.h"
#import <AssetsLibrary/AssetsLibrary.h>
//#import <CoreLocation/CoreLocation.h>
//#import <AddressBook/AddressBook.h>
#import "UIAlertView+Blocks.h"
#import <Photos/Photos.h>


#define FN_IOS_VERSION [[UIDevice currentDevice].systemVersion doubleValue]
#define SYSTEM_VERSION_iOS11 (FN_IOS_VERSION >= 11.0)


//    kCLAuthorizationStatusNotDetermined = 0, //没有询问是否开启
//    kCLAuthorizationStatusRestricted, //未授权，家长限制
//    kCLAuthorizationStatusDenied, //明确禁止授权
//    kCLAuthorizationStatusAuthorizedAlways //授权
//    kCLAuthorizationStatusAuthorizedWhenInUse
//    kCLAuthorizationStatusAuthorized

//typedef NS_ENUM(NSInteger, ALAuthorizationStatus) {
//    ALAuthorizationStatusNotDetermined NS_ENUM_DEPRECATED_IOS(6_0, 9_0) = 0, // 用户还没有选择权限
//    ALAuthorizationStatusRestricted NS_ENUM_DEPRECATED_IOS(6_0, 9_0),        // 应用未被授权 用户不能更改该应用程序的状态,可能由于活跃的限制/ /如家长控制到位。
//    ALAuthorizationStatusDenied NS_ENUM_DEPRECATED_IOS(6_0, 9_0),            //用户拒绝应用访问
//    ALAuthorizationStatusAuthorized NS_ENUM_DEPRECATED_IOS(6_0, 9_0)        // 用户允许应用访问
//}


//NSLocationWhenInUseUsageDescription    位置权限 使用期间 状态
//NSLocationAlwaysUsageDescription    位置权限 始终 状态
//NSLocationUsageDescription    用于访问位置权限
//NSCalendarsUsageDescription    用于访问日历权限
//NSContactsUsageDescription    用于访问联络人
//NSPhotoLibraryUsageDescription    用于访问相册
//NSRemindersUsageDescription    用于访问提醒

/*
About — prefs:root=General&path=About

Accessibility — prefs:root=General&path=ACCESSIBILITY

AirplaneModeOn— prefs:root=AIRPLANE_MODE

Auto-Lock — prefs:root=General&path=AUTOLOCK

Brightness — prefs:root=Brightness

Bluetooth — prefs:root=General&path=Bluetooth

Date& Time — prefs:root=General&path=DATE_AND_TIME

FaceTime — prefs:root=FACETIME

General— prefs:root=General

Keyboard — prefs:root=General&path=Keyboard

iCloud — prefs:root=CASTLE  iCloud

Storage & Backup — prefs:root=CASTLE&path=STORAGE_AND_BACKUP

International — prefs:root=General&path=INTERNATIONAL

Location Services — prefs:root=LOCATION_SERVICES

Music — prefs:root=MUSIC

Music Equalizer — prefs:root=MUSIC&path=EQ

Music VolumeLimit— prefs:root=MUSIC&path=VolumeLimit

Network — prefs:root=General&path=Network

Nike + iPod — prefs:root=NIKE_PLUS_IPOD

Notes — prefs:root=NOTES

Notification — prefs:root=NOTIFICATIONS_ID

Phone — prefs:root=Phone

Photos — prefs:root=Photos

Profile — prefs:root=General&path=ManagedConfigurationList

Reset — prefs:root=General&path=Reset

Safari — prefs:root=Safari
 
Siri — prefs:root=General&path=Assistant

Sounds — prefs:root=Sounds

SoftwareUpdate— prefs:root=General&path=SOFTWARE_UPDATE_LINK

Store — prefs:root=STORE

Twitter — prefs:root=TWITTER

Usage — prefs:root=General&path=USAGE

VPN — prefs:root=General&path=Network/VPN

Wallpaper — prefs:root=Wallpaper

Wi-Fi — prefs:root=WIFI

Setting—prefs:root=INTERNET_TETHERING
*/

@implementation AuthorizationChecker

#define kAPPName [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"]

#pragma mark -
+(BOOL)checkAuthority:(AVAuthorizationStatus)_status{
    return (_status == AVAuthorizationStatusAuthorized) || (_status == AVAuthorizationStatusNotDetermined);
}
+(void)showAlertController:(AuthorizedFinishBlock)_block device:(NSString *)_device{
    [[[UIAlertView alloc]initWithTitle:@"温馨提示" message:[NSString stringWithFormat:@"请开启‘%@’对 %@ 的使用权限",kAPPName,_device] cancelButtonItem:[RIButtonItem itemWithLabel:@"取消" action:^{
        _block();
    }] otherButtonItems:[RIButtonItem itemWithLabel:@"确定" action:^{
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }], nil]show];
}

#pragma mark - 摄像头权限
+(BOOL)checkCameraAuthority{
    return [self checkAuthority:[AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo]];
}
+(BOOL)cameraAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel{
    if ([self checkCameraAuthority]) {
        if (_success) {
            _success();
        }
    }else{
        [self showAlertController:_cancel device:@"相机"];
    }
    return [self checkCameraAuthority];
}

#pragma mark - 麦克风权限
//+(BOOL)checkAudioAuthority{
//    return [self checkAuthority:[AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio]];
//}
//+(BOOL)audioAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel{
//    if ([self checkAudioAuthority]) {
//        if (_success) {
//            _success();
//        }
//    }else{
//        [self showAlertController:_cancel device:@"麦克风"];
//    }
//    return [self checkAudioAuthority];
//}

#pragma mark - 相册权限
+(BOOL)checkAlbumAuthority{
    if (SYSTEM_VERSION_iOS11) {
        return YES;
    }
//    else{
//        return [ALAssetsLibrary authorizationStatus] == ALAuthorizationStatusAuthorized;
//    }
    return ([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusNotDetermined) || ([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusAuthorized);
}
+(BOOL)albumAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel
{
    if ([self checkAlbumAuthority]) {
        if (_success) {
            _success();
        }
    }else{
        [self showAlertController:_cancel device:@"照片"];
    }
    return [self checkAlbumAuthority];
}

#pragma mark - 位置权限
//+(BOOL)checkLocationAuthority {
//    return [CLLocationManager locationServicesEnabled];
//}
//+(BOOL)locationAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel{
//    if ([self checkLocationAuthority]) {
//        if (_success) {
//            _success();
//        }
//    }else{
//        [self showAlertController:_cancel device:@"位置"];
//    }
//    return [self checkLocationAuthority];
//}

#pragma mark - 推送通知权限
+(BOOL)checkPushNotificationAuthority {
    return [[UIApplication sharedApplication] currentUserNotificationSettings].types != UIUserNotificationTypeNone;
}
+(BOOL)pushNotificationAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel{
    
    if ([self checkPushNotificationAuthority]) {
        if (_success) {
            _success();
        }
    }else{
        [self showAlertController:_cancel device:@"通知"];
    }
    return [self checkPushNotificationAuthority];
}

#pragma mark - 通讯录权限
//+(BOOL)checkAddressBookAuthority {
//    return ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized || ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined;
//}
//+(BOOL)AddressBookAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel{
//
//    if ([self checkAddressBookAuthority]) {
//        if (_success) {
//            _success();
//        }
//    }else{
//        [self showAlertController:_cancel device:@"通讯录"];
//    }
//    return [self checkAddressBookAuthority];
//}

@end
