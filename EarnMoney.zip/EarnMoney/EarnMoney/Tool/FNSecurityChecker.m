//
//  SecurityChecker.m
//  HKCommonLib
//
//  Created by sun on 2018/1/12.
//  Copyright © 2018年 Haukit. All rights reserved.
//

#import "FNSecurityChecker.h"
#import "UIAlertView+Blocks.h"

@implementation FNSecurityChecker

+(void)checkAllRisk
{
    [self checkSignerIdentity];
    [self jailbreakWarning];
}

+(void)checkSignerIdentity
{
    if ([[[NSBundle mainBundle] infoDictionary] objectForKey:@"SignerIdentity"] != nil) {
        [[[UIAlertView alloc]initWithTitle:@"安全提醒" message:@"您的APP存在风险，请从AppStore下载" cancelButtonItem:[RIButtonItem itemWithLabel:@"" action:^{
            exit(0);
        }] otherButtonItems:nil, nil]show];
    }
}

+(void)jailbreakWarning
{
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"cydia://"]]
        || (getenv("DYLD_INSERT_LIBRARIES") != NULL)) {
        [[[UIAlertView alloc]initWithTitle:@"安全提醒" message:@"您的手机已越狱，存在安全性风险，是否继续" cancelButtonItem:[RIButtonItem itemWithLabel:@"退出" action:^{
            exit(0);
        }] otherButtonItems:[RIButtonItem itemWithLabel:@"继续" action:^{
            
        }], nil]show];
    }
}



@end
