//
//  AuthorizationChecker.h
//  HKCommonLib
//
//  Created by sun on 2018/1/2.
//  Copyright © 2018年 Haukit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

typedef void (^AuthorizedFinishBlock)();

@interface AuthorizationChecker : NSObject


#pragma mark - 摄像头权限
+(BOOL)checkCameraAuthority;
+(BOOL)cameraAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;

#pragma mark - 麦克风权限
+(BOOL)checkAudioAuthority;
+(BOOL)audioAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;

#pragma mark - 相册权限
+(BOOL)checkAlbumAuthority;
+(BOOL)albumAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;

#pragma mark - 推送通知权限
+(BOOL)checkPushNotificationAuthority;
+(BOOL)pushNotificationAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;

#pragma mark - 位置权限
+(BOOL)checkLocationAuthority;
+(BOOL)locationAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;

#pragma mark - 通讯录权限
+(BOOL)checkAddressBookAuthority;
+(BOOL)AddressBookAuthorityCheckSuccess:(AuthorizedFinishBlock)_success cancel:(AuthorizedFinishBlock)_cancel;


@end
