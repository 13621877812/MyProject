//
//  SystemInfoUtils.h
//  DeviceInfoDemo
//
//  Created by sun on 2017/3/21.
//  Copyright © 2017年 Haukit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CLLocation.h>


@interface AFSystemInfoUtils : NSObject

//App_Name	a1	接入App的包名	Package Name
+(NSString *)getAppName;

//App_Version	a2	接入App的版本号	—
+(NSString *)getAppVersion;

//Sdk_Version	a3	SDK的版本号	—
+(NSString *)getSdkVersion;

//Os	a4	操作系统类型	—		需要
+(NSString *)getOsType;

//Osv	a5	操作系统版本	—		需要
+(NSString *)getOsVersion;

//Did	a6	设备唯一标识码（UDID）	—		需要
+(NSString *)getUDID;

//IDFA	a7	广告标示符			需要
+(NSString *)getIDFA;

//IDFV	a8	Vendor标识符			需要
+(NSString *)getIDFV;

//Root	a9	是否已经越狱	1代表已越狱	需要
+(NSString *)isJailbreak;

//GPS	b1	经纬度信息	格式：经度,纬度	需要
+(CLLocation *)getLocation;
//GPS   格式：经度,纬度
+(NSString *)getLocationString;

//Net	b2	网络类型	Wi-Fi / 3G / 4G …
+(NSString *)getNetType;

//Device	b3	设备型号	—		需要 model
+(NSString *)getDevice;

//HostName	b4	主机名	—		需要
+(NSString *)getHostName;

//Wifi_SSID	b5	连接wifi的名称		需要
+(NSString *)getWifiSSID;

//Wifi_MAC	b6	连接的wifi mac地址		需要
+(NSString *)getWifiMAC;

//Time	t1	当前系统时间戳	精确到毫秒
+(NSString *)getTimeStamp;

//system_time	g5	系统上次启动时间点	精确到毫秒
+(NSString *)getLastSystemStartTime;

//screen	g6	屏幕分辨率信息
+(NSString *)getScreenResolution;

//carrier	g7	运营商信息	中国移动为0,中国联通为1,中国电信为2
+(NSString *)getPhoneCarrier;

//是否是模拟器
+(NSString *)isEmulator;

@end
