//
//  ZYLocationManager.m
//  ZYHainanLib
//
//  Created by sun on 16/8/1.
//  Copyright © 2016年 Haukit. All rights reserved.
//

#import "ZYLocationManager.h"

#define UpdataLocationTimeInterval (8*60)
@interface ZYLocationManager ()
//<BMKLocationServiceDelegate>
@end
@implementation ZYLocationManager
singleton_implementation(ZYLocationManager)

-(instancetype)init
{
    if (self = [super init]) {
//        _locService = [[BMKLocationService alloc]init];
//        _locService.delegate = self;
//        _locService.desiredAccuracy = kCLLocationAccuracyBest;
//        _locService.distanceFilter = 100.0f;
        
    }
    return self;
}



- (void)startUpdatingLocation {
    lastTime = 0.0;
    self.latitude = 0;
    self.longitude = 0;
    //启动LocationService
//    [_locService startUserLocationService];
}

#pragma mark - HLLocationDelegate
//
////实现相关delegate 处理位置信息更新
////处理方向变更信息
//- (void)didUpdateUserHeading:(BMKUserLocation *)userLocation
//{
////    NSLog(@"heading is %@",userLocation.heading);
//}
////处理位置坐标更新
//- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
//{
//    self.getLocationSuccess = YES;
//    self.latitude = userLocation.location.coordinate.latitude;
//    self.longitude = userLocation.location.coordinate.longitude;
//    NSLog(@"didUpdateUserLocation lat %f,long %f",userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude);
//   
//}
//
//- (void)didFailToLocateUserWithError:(NSError *)error
//{
////    self.longitude = 0.0;
////    self.latitude = 0.0;
//    NSLog(@"location error");
//}
//#pragma mark -- 计算距离
//
//+ (NSString *)distanceFromCurrentLocation:(CLLocation *)currentLocation ToBeforeLocation:(CLLocation *)beforeLocation {
//
//    BMKMapPoint point1 = BMKMapPointForCoordinate(CLLocationCoordinate2DMake(currentLocation.coordinate.latitude,currentLocation.coordinate.longitude));
//    BMKMapPoint point2 = BMKMapPointForCoordinate(CLLocationCoordinate2DMake(beforeLocation.coordinate.latitude,beforeLocation.coordinate.longitude));
//    CLLocationDistance meters = BMKMetersBetweenMapPoints(point1,point2);
//    NSLog(@"distance --- %f",meters);
//
//    if (meters < 1000) {
//        NSString *distance = [NSString stringWithFormat:@"%.0f米",meters];
//        return distance;
//    }else {
//        NSString * distance = [NSString stringWithFormat:@"%.2f公里",meters/1000];
//        return distance;
//    }
//}
@end
