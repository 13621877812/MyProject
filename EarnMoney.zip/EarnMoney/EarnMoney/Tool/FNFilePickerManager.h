//
//  FNFilePickerManager.h
//  FNBase
//
//  Created by Eastman on 2018/10/31.
//  Copyright © 2018 FNCONN. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define FileOutofLengthTips @"文件过大"

/**
 选择的文件类型

 - FNFileTypeImage: 图片格式，包括jpg,jpeg,png,bmp,3gpp
 - FNFileTypePdf: PDF格式
 - FNFileTypePdf: 未知格式
 */
typedef NS_ENUM(NSUInteger,FNFileType) {
    FNFileTypeImage = 0,
    FNFileTypePdf ,
    FNFileTypeExcel ,
    FNFileTypePPT ,
    FNFileTypeWord ,
    FNFileTypeVideo ,
    FNFileTypeUnknow
};

typedef NS_ENUM(NSUInteger,FNFilePickerSourceType) {
    FNFilePickerSourceTypeCamera = 0, //相机
    FNFilePickerSourceTypePhotoLibrary , //相册
    FNFilePickerSourceTypeDocument //文件
};

typedef void(^FilePickerSuccess)(id data, NSURL *fileUrl, NSString *filePath, FNFileType fileType);
typedef void(^FilePickerFailure)(NSError *error, NSString *errorMsg);

@interface FNFilePickerManager : NSObject

@property (nonatomic,copy) FilePickerSuccess success;
@property (nonatomic,copy) FilePickerFailure failure;
@property (nonatomic,strong) UIViewController *presentationCtrl;
@property (nonatomic,assign) NSUInteger maxLength;

/**
 图片选择器，默认弹出ActionSheet用户选择“相册，相机”

 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)imagePickerFromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;

/**
 图片选择器，默认弹出ActionSheet用户选择“相册，相机”
 
 @param presentationCtrl 弹出文件选择器的父控制器
 @param maxLength 压缩到最大值 eg：(压缩到2M，maxLength = 2000*1000)
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)imagePickerFromPresentationController:(UIViewController *)presentationCtrl compressToMaxLength:(NSUInteger)maxLength success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;


/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”

 @param allowedUTIs 当用户选择Document时，所支持的文件类型UITIs
 @param mode UIDocumentPickerMode,default is UIDocumentPickerModeOpen
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerWithDocumentTypes:(NSArray <NSString *>* __nonnull)allowedUTIs inMode:(UIDocumentPickerMode)mode fromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;

/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”
 
 @param allowedUTIs 当用户选择Document时，所支持的文件类型UITIs
 @param mode UIDocumentPickerMode,default is UIDocumentPickerModeOpen
 @param maxLength 压缩到最大值 eg：(压缩到2M，maxLength = 2000*1000)
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerWithDocumentTypes:(NSArray <NSString *>* __nonnull)allowedUTIs inMode:(UIDocumentPickerMode)mode compressToMaxLength:(NSUInteger)maxLength fromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;

/**
 文件选择器，默认弹出ActionSheet用户选择“相册，相机，文件”

 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 @return FNFilePickerManager实例
 */
+(instancetype)filePickerFromPresentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;


/**
 文件选择器

 @param sourceType 文件选择类型：相册，相机，文件
 @param presentationCtrl 弹出文件选择器的父控制器
 @param success 选取文件成功时调用的block
 @param failure 选取文件失败时调用的block
 */
-(void)filePickSourceFrom:(FNFilePickerSourceType)sourceType presentationController:(UIViewController *)presentationCtrl success:(FilePickerSuccess)success failure:(FilePickerFailure)failure;

@end

NS_ASSUME_NONNULL_END
