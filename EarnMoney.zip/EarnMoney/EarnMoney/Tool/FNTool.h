//
//  FNTool.h
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FNTool : NSObject

//获取documents下的文件路径
+ (NSString *)getDocumentsPath:(NSString *)fileName;
+ (NSString *)getHomePath:(NSString *)fileName;
+ (NSString *)getDesktopPath:(NSString *)fileName;
+ (NSString *)getAppPath:(NSString *)fileName;
+ (NSString *)getResourcePath:(NSString *)fileName;

+ (NSString *)homePath;
+ (NSString *)desktopPath;
+ (NSString *)documentPath;
+ (NSString *)appPath;
+ (NSString *)resourcePath;

+ (BOOL)checkoutWithIdentityCard:(NSString *)identityCard;
@end
