//
//  FNNavigationController.m
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNNavigationController.h"

@interface FNNavigationController ()

@end

@implementation FNNavigationController

+ (void)initialize {
    
//    // 设置整个项目所有item的主题样式
//    UIBarButtonItem *item = [UIBarButtonItem appearance];
//    // 设置普通状态
//    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
//    textAttrs[NSForegroundColorAttributeName] = [UIColor blackColor];
//    textAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:15.0f];
//    [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
//    // 设置高亮状态
//    NSMutableDictionary *hightlightedTextAttrs = [NSMutableDictionary dictionary];
//    hightlightedTextAttrs[NSForegroundColorAttributeName] = [UIColor whiteColor];
//    hightlightedTextAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:15.0f];
//    [item setTitleTextAttributes:hightlightedTextAttrs forState:UIControlStateHighlighted];
//    // 设置不可用状态
//    NSMutableDictionary *disableTextAttrs = [NSMutableDictionary dictionary];
//    disableTextAttrs[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:0.7];
//    disableTextAttrs[NSFontAttributeName] = textAttrs[NSFontAttributeName];
//    [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateDisabled];
//
    // 设置整个项目所有Title的主题样式
    UINavigationBar *bar = [UINavigationBar appearance];
    [bar setTranslucent:NO];
//    [bar setTintColor:[UIColor whiteColor]];
//    [bar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
//    [bar setShadowImage:[UIImage new]];
////    bar.barStyle = UIBarStyleBlack;
//    NSMutableDictionary *titleTextAttrs = [NSMutableDictionary dictionary];
//    titleTextAttrs[NSForegroundColorAttributeName] = [UIColor blackColor];
//    titleTextAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:17];
//    [bar setTitleTextAttributes:titleTextAttrs];

}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.childViewControllers.count >= 1) {
        viewController.hidesBottomBarWhenPushed = YES;

        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    }
    [super pushViewController:viewController animated:animated];
}

-(void)goBack
{
    
    [self popViewControllerAnimated:YES];
}

-(void)viewDidLoad {
    [super viewDidLoad];
    self.interactivePopGestureRecognizer.delegate = (id)self;
}


@end
