//
//  AppDelegate.m
//  EarnMoney
//
//  Created by sun on 2018/12/20.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "AppDelegate.h"
#import "FNLoginManager.h"
#import "FNLaunchIntroductionView.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
 

    
    
    
    self.window = [UIWindow new];
    self.window.backgroundColor = [UIColor whiteColor];
    self.window.rootViewController = [[FNLoginManager shareInstance] switchAppWindowRootViewController];
    [self.window makeKeyAndVisible];

    //引导页面
    [FNLaunchIntroductionView sharedWithImages:@[@"guidepage_one",@"guidepage_two",@"guidepage_three",@"guidepage_four",@"guidepage_five"] buttonImage:@"start" buttonFrame:CGRectMake(FNScreenWidth/2.0-178/2.0, FNScreenHeight-100, 178, 32)];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
