//
//  ViewController.m
//  EarnMoney
//
//  Created by sun on 2018/12/20.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
