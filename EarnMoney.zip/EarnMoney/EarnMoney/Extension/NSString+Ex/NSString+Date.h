//
//  NSString+Date.h
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Date)

//传入时间与当前时间的间隔
//eg：一分钟前，一天前，...
+(NSString *)timeDescriptionToNow:(NSString*)pubTimeSting;

/**
 *  date日期 ->格式化的日期 eg. @"yyyy-MM-dd"
 */
- (NSString*) stringFromDate:(NSDate*) date formate:(NSString*)formate;

/**
 *   格式化的日期 ->格式化的日期 eg. @"yyyy-MM-dd"
 */
- (NSDate *) dateFromFomate:(NSString *)datestring formate:(NSString*)formate;

/**
 *   格式化的日期 ->格式化的日期 eg. @"MM-dd HH:mm"
 */
- (NSString *)fomateString;

//"2016-03-29 10:36:17"
/**
 *  self       日期String
 *  @param formate       日期格式  eg. @"yyyy-MM-dd HH:mm:ss"
 *  @param returnFomater 返回的日期格式 eg. @"yyyy-MM-dd"
 */
-(NSString *)stringFromDateStingFormate:(NSString *)formate returnFomaterString:(NSString *)returnFomater;

/**
 * dateComponents 转化为日期String
 *  @param dateComponents dateComponents
 *  @param formate       日期格式  eg. @"yyyy-MM-dd HH:mm:ss"
 */
+(NSString *)dateComponentsTransToDateStringDateComponents:(NSDateComponents *)dateComponents formate:(NSString *)formate;


+(NSString *)timeStampFromNow;
-(NSString *)timestampTransDateWithFormatter:(NSString *)formatter;
+(NSString*)getCurrentTimes;


/**
 日期比较大小

 @param currentDay 当前日期
 @param BaseDay 比较的日期
 @return 比较结果
 */
+ (NSComparisonResult)compareOneDay:(NSDate *)currentDay withAnotherDay:(NSDate *)BaseDay;

@end
