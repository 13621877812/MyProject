//
//  NSString+Regex.h
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Regex)

-(BOOL)validateStringWithRegex:(NSString*)regexString;

@end
