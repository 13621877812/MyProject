//
//  NSString+Money.m
//  FNBase
//
//  Created by sun on 2018/9/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "NSString+Money.h"

@implementation NSString (Money)


/**
 * 货币格式化后的String转化成NSDecimalNumber
 * ¥1,234,234.37 -> 1234.37
 * $1234.37 -> 1234.37
 */
-(NSDecimalNumber *)moneyFormatterTransformToDecimalNumber
{
    if (self.length == 0) {
        return [NSDecimalNumber new];
    }
    
    NSString *noUSDSignString =  [self stringByReplacingOccurrencesOfString:@"$" withString:@""];
    NSString *noRMBSignString =  [noUSDSignString stringByReplacingOccurrencesOfString:@"¥" withString:@""];
    NSString *formString = [noRMBSignString stringByReplacingOccurrencesOfString:@"," withString:@""];
    
    NSDecimalNumber *decimalNum = [NSDecimalNumber decimalNumberWithString:formString];
    return decimalNum;
}

/**
 * NSDecimalNumber 转化成 货币格式化后的String
 * 1234.37 ->  ¥1,234,234.37
 * 1234.37 -> $1234.37
 */
+(NSString *)decimalNumberTransformToMoneyFormatter:(NSDecimalNumber *)decimalNum withSign:(NSString *)sign
{
    NSString *money = [decimalNum stringValue];
    if (sign.length == 0) {
        sign = @"¥";
    }
    
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.positiveFormat = @",##0.00"; // 正数格式
    NSString *money2 = [formatter stringFromNumber:[NSNumber numberWithDouble:decimalNum.doubleValue]];
    
    return [NSString stringWithFormat:@"%@%@",sign,money2];
}


/**
 * 货币格式化后的String +  货币格式化后的String = 货币格式化后的String
 * ¥1,234,234.37 + ¥1,234,234.37 = ¥1,234,234.37
 * $1,234,234.37 + $1,234,234.37 = $1,234,234.37
 */
+(NSString *)formatterMoney:(NSString *)money1 addMoney:(NSString *)money2
{
    //无币种符号
    if (!([money1 hasPrefix:@"¥"] || [money1 hasPrefix:@"$"])) {
        return @"";
    }
    //币种不同
    if (![[money1 substringToIndex:1] isEqualToString:[money2 substringToIndex:1]]) {
        return @"";
    }
    NSDecimalNumber *decimalNum1 = [money1 moneyFormatterTransformToDecimalNumber];
    NSDecimalNumber *decimalNum2 = [money2 moneyFormatterTransformToDecimalNumber];
    NSDecimalNumber *addDecimalNum = [decimalNum1 decimalNumberByAdding:decimalNum2];
    
    return [self decimalNumberTransformToMoneyFormatter:addDecimalNum withSign:[money1 substringToIndex:1]];
}

/** 2018/11/01 Add by fpm0311 for fna2018Q40408 start **/
-(NSString *)toMoneyString
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.positiveFormat = @",##0.00"; // 正数格式
    NSString *money = [formatter stringFromNumber:[NSNumber numberWithDouble:[[self stringByReplacingOccurrencesOfString:@"," withString:@""] doubleValue]]];
    return money;
}

-(NSString *)toDoubleString
{
    return [self stringByReplacingOccurrencesOfString:@"," withString:@""];
}

//中文币种描述转成英文缩写 eg: 人民币 -> CNY
-(NSString *)currencyDescChangeToAbbreviation
{
    NSDictionary *currDic = @{@"CNY":@"人民币",
                              @"USD":@"美元"
                              };
    NSArray *keys = currDic.allKeys;
    for (NSString *key in keys) {
        if ([currDic[key] isEqualToString:self]) {
            return key;
        }
    }
    return self;
}

//英文缩写转成中文币种描述 eg: CNY -> 人民币
-(NSString *)currencyAbbreviationChangeToDesc
{
    NSDictionary *currDic = @{@"CNY":@"人民币",
                              @"USD":@"美元"
                              };
    NSString *desc = [currDic objectForKey:self];
    if (desc.length != 0) {
        return desc;
    }else{
        return self;
    }
}
/** 2018/11/01 Add by fpm0311 for fna2018Q40408 end   **/

@end

/**
 * Revision History
 * ------------------------------------------------------------
 * Version       Date       Author      Note
 * ------------------------------------------------------------
 *  1.0.0      2018/09/05    fpm0311      Add
 *  1.0.1      2018/11/01    fpm0311   fna2018Q40408
 */
