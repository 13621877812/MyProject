//
//  NSString+FulllWidth.h
//  FNBase
//
//  Created by sun on 2018/11/20.
//  Copyright © 2018 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (FullWidth)


/**
 全角转半角
 @return 转化后的文本
 */
- (NSString *)transformFullwidthToHalfwidth;

/**
 半角转全角
 @return 转化后的文本
 */
- (NSString *)transformHiraganaKatakana;

@end

NS_ASSUME_NONNULL_END
