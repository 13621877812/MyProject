//
//  NSString+Intercept.m
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "NSString+Intercept.h"

@implementation NSString (Intercept)

-(NSString *)lastSubStringWithLength:(NSInteger)length
{
    if (self.length <= length) {
        return self;
    } else {
        return [self substringFromIndex:self.length-length];
    }
}

-(NSString *)begainSubStringWithLength:(NSInteger)length
{
    if (self.length <= length) {
        return self;
    }else{
        return [self substringToIndex:length];
    }
}
@end
