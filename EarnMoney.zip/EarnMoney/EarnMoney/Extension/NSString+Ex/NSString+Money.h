//
//  NSString+Money.h
//  FNBase
//
//  Created by sun on 2018/9/5.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger,FNCurrencyType) {
    FNCurrencyTypeUSD = 1,
    FNCurrencyTypeCNY
};

@interface NSString (Money)

//PS:注意! iOS11之后kCFNumberFormatterCurrencyStyle 在中文状态下前缀变成了CN￥不是￥.这里选择使用kCFNumberFormatterDecimalStyle

/**
 * 系统API
 *
 * 转换成 NSDecimalNumber .
 *
 * //1、NSString -> NSDecimalNumber
 * NSDecimalNumber *num1 = [NSDecimalNumber decimalNumberWithString:@"100"];
 *
 * //2、NSNumber -> NSDecimal -> NSDecimalNumber(基础类型的话，先转成NSNumber)
 * NSDecimalNumber *num2 = [NSDecimalNumber decimalNumberWithDecimal:[[NSNumber numberWithInt:50] decimalValue]];
 *
 * 加
 * -(NSDecimalNumber *)decimalNumberByAdding:(NSDecimalNumber *)decimalNumber;
 * 减
 * -(NSDecimalNumber *)decimalNumberBySubtracting:(NSDecimalNumber *)decimalNumber;
 * 乘
 * -(NSDecimalNumber *)decimalNumberByMultiplyingBy:(NSDecimalNumber *)decimalNumber;
 * 除
 * -(NSDecimalNumber *)decimalNumberByDividingBy:(NSDecimalNumber *)decimalNumber;
 *
 */

///**
// * 货币格式化后的String转化成Double
// * ¥1,234,234.37 -> 1234.37
// * $1234.37 -> 1234.37
// */
//-(double)moneyFormatterTransformToDouble;

/**
 * 货币格式化后的String 转化成 NSDecimalNumber
 * ¥1,234,234.37 -> 1234.37
 * $1234.37 -> 1234.37
 */
-(NSDecimalNumber *)moneyFormatterTransformToDecimalNumber;

/**
 * NSDecimalNumber 转化成 货币格式化后的String
 * 1234.37 ->  ¥1,234,234.37
 * 1234.37 -> $1234.37
 */
+(NSString *)decimalNumberTransformToMoneyFormatter:(NSDecimalNumber *)decimalNum withSign:(NSString *)sign;

/**
 * 货币格式化后的String +  货币格式化后的String = 货币格式化后的String
 * ¥1,234,234.37 + ¥1,234,234.37 = ¥1,234,234.37
 * $1,234,234.37 + $1,234,234.37 = $1,234,234.37
 */
+(NSString *)formatterMoney:(NSString *)money1 addMoney:(NSString *)money2;


/**
 1234.3 -> 1,234.30
 */
-(NSString *)toMoneyString;
/**
 1,234.30 -> 1234.30
 */
-(NSString *)toDoubleString;

//中文币种描述转成英文缩写 eg: 人民币 -> CNY
-(NSString *)currencyDescChangeToAbbreviation;
//英文缩写转成中文币种描述 eg: CNY -> 人民币
-(NSString *)currencyAbbreviationChangeToDesc;

@end
