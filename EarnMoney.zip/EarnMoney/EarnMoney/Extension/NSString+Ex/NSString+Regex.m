//
//  NSString+Regex.m
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "NSString+Regex.h"

@implementation NSString (Regex)

-(BOOL)validateStringWithRegex:(NSString*)regexString
{
    NSPredicate *regex = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regexString];
    return [regex evaluateWithObject:self];
}


@end
