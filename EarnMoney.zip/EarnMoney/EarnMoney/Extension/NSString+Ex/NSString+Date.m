//
//  NSString+Date.m
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "NSString+Date.h"
#import <CoreGraphics/CoreGraphics.h>

@implementation NSString (Date)

+(NSString *)timeDescriptionToNow:(NSString*)pubTimeSting
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm"];
    
    NSString* beginStr = [NSString stringWithFormat:@"%@", pubTimeSting];
    
    NSDate *beginDate=[formatter dateFromString:beginStr];
    
    //转换生时间戳
    
    NSInteger  beginTime=[beginDate timeIntervalSince1970];
    
    //把后台获取的时间戳转换为日期格式
    NSDate * conformTimesp = [NSDate dateWithTimeIntervalSince1970:beginTime];
    //    NSDate * theDate = [formatter dateFromString:string];
    NSString  * timeString = @"";
    NSDate *dat = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval now = [dat timeIntervalSince1970]*1;
    NSTimeInterval late = [conformTimesp timeIntervalSince1970]*1;
    NSTimeInterval cha = now - late;
    if (cha/3600<1) {
        timeString = [NSString stringWithFormat:@"%f", cha/60];
        timeString = [timeString substringToIndex:timeString.length-7];
        timeString=[NSString stringWithFormat:@"%@分钟前", timeString];
    }
    if (cha/3600>1&&cha/86400<1) {
        timeString = [NSString stringWithFormat:@"%f", cha/3600];
        timeString = [timeString substringToIndex:timeString.length-7];
        timeString=[NSString stringWithFormat:@"%@小时前", timeString];
        
    }
    if (cha/86400>1 )
    {
        
        timeString = [NSString stringWithFormat:@"%f", cha/86400];
        timeString = [timeString substringToIndex:timeString.length-7];
        CGFloat time = [timeString integerValue];
        timeString=[NSString stringWithFormat:@"%@天前", timeString];
        if (time > 30)
        {
            timeString = [formatter stringFromDate:conformTimesp]; //[formatter stringFromDate:conformTimesp];
        }
    }
    
    return timeString;
    
}


- (NSString*) stringFromDate:(NSDate*) date formate:(NSString*)formate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formate];
    NSString *str = [formatter stringFromDate:date];
    return str;
}

- (NSDate *) dateFromFomate:(NSString *)datestring formate:(NSString*)formate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formate];
    NSDate *date = [formatter dateFromString:datestring];
    return date;
}


//"2016-03-29 10:36:17"
/**
 *  self       日期String
 *  @param formate       日期格式  eg. @"yyyy-MM-dd HH:mm:ss"
 *  @param returnFomater 返回的日期格式 eg. @"yyyy-MM-dd"
 */
-(NSString *)stringFromDateStingFormate:(NSString *)formate returnFomaterString:(NSString *)returnFomater
{
    NSDate *createDate = [self dateFromFomate:self formate:formate];
    NSString *text = [self stringFromDate:createDate formate:returnFomater];
    return text;
}

//Sat Jan 12 11:50:16 +0800 2013
- (NSString *)fomateString
{
    NSString *formate = @"E MMM d HH:mm:ss Z yyyy";
    NSDate *createDate = [self dateFromFomate:self formate:formate];
    NSString *text = [self stringFromDate:createDate formate:@"MM-dd HH:mm"];
    return text;
}

+(NSString *)dateComponentsTransToDateStringDateComponents:(NSDateComponents *)dateComponents formate:(NSString *)formate
{
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *date = [gregorian dateFromComponents:dateComponents];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:formate];
    NSString *dateString = [dateFormat stringFromDate:date];
    return dateString;
}

+(NSString *)timeStampFromNow
{
    NSTimeInterval time = [[NSDate date] timeIntervalSince1970];
    long long dTime = [[NSNumber numberWithDouble:time] longLongValue]; // 将double转为long long型
    return [NSString stringWithFormat:@"%llu",dTime]; // 输出long long型
}

-(NSString *)timestampTransDateWithFormatter:(NSString *)formatter
{
    //时间戳转字符串
    NSTimeInterval interval = [self doubleValue] / 1000.0;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:interval];
    //实例化一个NSDateFormatter对象
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    //设定时间格式,这里可以设置成自己需要的格式
    [dateFormatter setDateFormat:formatter];
    NSString *currentDateStr = [dateFormatter stringFromDate:date];
    return currentDateStr;
}

+(NSString*)getCurrentTimes
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *datenow = [NSDate date];
    NSString *currentTimeString = [formatter stringFromDate:datenow];
    return currentTimeString;
}


/**
 日期比较大小
 
 @param currentDay 当前日期
 @param BaseDay 比较的日期
 @return 比较结果
 */
+ (NSComparisonResult)compareOneDay:(NSDate *)currentDay withAnotherDay:(NSDate *)BaseDay
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd-HHmmss"];
    NSString *currentDayStr = [dateFormatter stringFromDate:currentDay];
    NSString *BaseDayStr = [dateFormatter stringFromDate:BaseDay];
    NSDate *dateA = [dateFormatter dateFromString:currentDayStr];
    NSDate *dateB = [dateFormatter dateFromString:BaseDayStr];
    NSComparisonResult result = [dateA compare:dateB];
    return result;
//    if (result == NSOrderedDescending) {
//        //NSLog(@"Date1  is in the future");
//        return 1;
//    }
//    else if (result == NSOrderedAscending){
//        //NSLog(@"Date1 is in the past");
//        return -1;
//    }
//    //NSLog(@"Both dates are the same");
//    return 0;
}

@end
