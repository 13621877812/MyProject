//
//  NSString+FulllWidth.m
//  FNBase
//
//  Created by sun on 2018/11/20.
//  Copyright © 2018 sun. All rights reserved.
//

#import "NSString+FullWidth.h"

@implementation NSString (FullWidth)

- (NSString *)transformFullwidthToHalfwidth{
    NSMutableString *convertedString = [self mutableCopy];
    CFStringTransform((CFMutableStringRef)convertedString, NULL, kCFStringTransformFullwidthHalfwidth, false);
    return [NSString stringWithString:convertedString];
}

- (NSString *)transformHiraganaKatakana{
    NSMutableString *convertedString = [self mutableCopy];
    CFStringTransform((CFMutableStringRef)convertedString, NULL, kCFStringTransformHiraganaKatakana, false);
    return [NSString stringWithString:convertedString];
}

@end

/**
 * Revision History
 * ------------------------------------------------------------
 * Version       Date       Author      Note
 * ------------------------------------------------------------
 *  1.0.0     2018-11-20    fpm0311   fna2018Q40321
 */
