//
//  NSString+Emoji.h
//  FNBase
//
//  Created by sun on 2018/11/20.
//  Copyright © 2018 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Emoji)

//判断是否含有表情符号 yes-有 no-没有
+ (BOOL)stringContainsEmoji:(NSString *)string;

//是否是系统自带九宫格输入 yes-是 no-不是
+ (BOOL)isNineKeyBoard:(NSString *)string;

//判断第三方键盘中的表情
+ (BOOL)hasEmoji:(NSString*)string;

//去除表情
+ (NSString *)disableEmoji:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
