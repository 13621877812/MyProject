//
//  NSArray+Swizzling.m
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "NSArray+Swizzling.h"
#import "NSObject+Extension.h"
#import <objc/message.h>
@implementation NSArray (Swizzling)
+ (void)load
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        [objc_getClass("__NSArrayI") swizzleClassMethod:@selector(objectAtIndex:) withMethod:@selector(dg_objectAtIndex:)];
        [objc_getClass("__NSSingleObjectArrayI") swizzleClassMethod:@selector(objectAtIndex:) withMethod:@selector(dg_Single_objectAtIndex:)];

    });
}


- (id)dg_objectAtIndex:(NSUInteger)index {
    if (self.count == 0) {
        NSLog(@"%s can't get any object from an empty array", __FUNCTION__);
        return nil;
    }
    
    if (index > self.count) {
        NSLog(@"%s index out of bounds in array", __FUNCTION__);
        return nil;
    }
    
    return [self dg_objectAtIndex:index];
}

-(id)dg_Single_objectAtIndex:(NSUInteger)index {
    if (self.count == 0) {
        NSLog(@"%s can't get any object from an empty array", __FUNCTION__);
        return nil;
    }
    
    if (index > self.count) {
        NSLog(@"%s index out of bounds in array", __FUNCTION__);
        return nil;
    }
    
    return [self dg_Single_objectAtIndex:index];
}

@end
