//
//  UIViewController+Nav.h
//  FNFactoring
//
//  Created by sun on 2018/11/9.
//  Copyright © 2018 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (Nav)


/**
 移除当前控制器并push到指定VC

 @param pushViewController 要push的VC
 */
- (void)removeCurrentViewControllerThenPushToViewController:(UIViewController *)pushViewController;

/**
 从导航栈中移除fromViewControllerClasses 到[self class]之间的VC

 @param startClasses fromViewControllerClasses
 */
- (void)removeViewControllerFromNavigationStackWithStartControllerClasses:(NSArray *)startClasses;


/**
 从导航栈中移除fromViewControllerClass 到 toViewControllerClass之间的VC

 @param fromClass fromViewControllerClass
 @param toClass toViewControllerClasss
 @return 是否移除Controller成功
 */
- (BOOL)canRemoveViewControllerFromNavigationStackFrom:(Class)fromClass
                                                    to:(Class)toClass;

@end

NS_ASSUME_NONNULL_END
