//
//  NSObject+JQUtils.m
//  ouyeelf
//
//  Created by mac on 16/3/3.
//
//

#import "NSObject+JQUtils.h"

@implementation NSObject (JQUtils)

- (BOOL)isValided
{
    return !(self == nil || [self isKindOfClass:[NSNull class]]);
}

- (BOOL)isNotNSNull
{
    return ![self isKindOfClass:[NSNull class]];
}

- (BOOL)isEmpty
{
    return (self == nil
            || [self isKindOfClass:[NSNull class]]
            || ([self respondsToSelector:@selector(length)]
                && [(NSData *)self length] == 0)
            || ([self respondsToSelector:@selector(count)]
                && [(NSArray *)self count] == 0));
}

- (BOOL)isNotEmpty
{
    return !(self == nil
             || [self isKindOfClass:[NSNull class]]
             || ([self respondsToSelector:@selector(length)]
                 && [(NSData *)self length] == 0)
             || ([self respondsToSelector:@selector(count)]
                 && [(NSArray *)self count] == 0));
}


- (BOOL)isNotEmptyDictionary
{
    if ([self isNotEmpty])
    {
        return [self isKindOfClass:[NSDictionary class]];
    }
    
    return NO;
}

@end
