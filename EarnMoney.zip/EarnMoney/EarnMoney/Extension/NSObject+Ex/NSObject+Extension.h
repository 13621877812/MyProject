//
//  NSObject+Extension.h
//  NSObjectTest
//
//  Created by Andrew on 2018/3/22.
//  Copyright © 2018年 Andrew. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Extension)

- (id)defaultValue:(id)defaultData;

NSString *getSafeString(NSString *string);

NSDictionary *getSafeDictionary(NSDictionary *dictionary);

NSArray *getSafeArray(NSArray *array);

@end

@interface NSObject (Swizzle)

+ (void)swizzleClassMethod:(SEL)originalSelector withMethod:(SEL)newSelector;

+ (void)swizzleInstanceMethodWithClass:(Class)class originalMethod:(SEL)originalSelector newMethod:(SEL)newSelector;

@end
