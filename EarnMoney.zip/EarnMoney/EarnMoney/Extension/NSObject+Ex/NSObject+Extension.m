//
//  NSObject+Extension.m
//  NSObjectTest
//
//  Created by Andrew on 2018/3/22.
//  Copyright © 2018年 Andrew. All rights reserved.
//

#import "NSObject+Extension.h"
// utils
#import <objc/message.h>


@implementation NSObject (Extension)

- (id)defaultValue:(id)defaultData {

    if (![defaultData isKindOfClass:[self class]]) {
        return defaultData;
    }
    
    if ([self isEmptyObject]) {
        return defaultData;
    }
    
    return self;
}

- (BOOL)isEmptyObject {
    if ([self isEqual:[NSNull null]]) {
        return YES;
    }
    
    if ([self isKindOfClass:[NSString class]]) {
        if ([(NSString *)self length] == 0) {
            return YES;
        }
    }
    
    if ([self isKindOfClass:[NSArray class]]) {
        if ([(NSArray *)self count] == 0) {
            return YES;
        }
    }
    
    if ([self isKindOfClass:[NSDictionary class]]) {
        if ([(NSDictionary *)self count] == 0) {
            return YES;
        }
    }
    return NO;
}

NSString *getSafeString(NSString *string) {
    if ([[string lowercaseString] isEqualToString:@"null"] || [[string lowercaseString] isEqualToString:@"<null>"] || [[string lowercaseString] isEqualToString:@"(null)"]) {
        return @"";
    }
    return [string defaultValue:@""];
}

NSDictionary *getSafeDictionary(NSDictionary *dictionary) {
    return [dictionary defaultValue:@{}];
}

NSArray *getSafeArray(NSArray *array) {
    return [array defaultValue:@[]];
}

@end

@implementation NSObject (Swizzle)

+ (void)swizzleClassMethod:(SEL)originalSelector withMethod:(SEL)newSelector {
    
    Class class = [self class];
    Class metaclass = objc_getMetaClass(NSStringFromClass(class).UTF8String);
    
    Method originalMethod = class_getClassMethod(class, originalSelector);
    Method swizzledMethod = class_getClassMethod(class, newSelector);
    
    if (class_addMethod(metaclass,
                        originalSelector,
                        method_getImplementation(swizzledMethod),
                        method_getTypeEncoding(swizzledMethod)) ) {
        /* swizzing super class method, added if not exist */
        class_replaceMethod(metaclass,
                            newSelector,
                            method_getImplementation(originalMethod),
                            method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
}

+ (void)swizzleInstanceMethodWithClass:(Class)class originalMethod:(SEL)originalSelector newMethod:(SEL)newSelector {
    /* if current class not exist selector, then get super*/
    Method originalMethod = class_getInstanceMethod(class, originalSelector);
    Method swizzledMethod = class_getInstanceMethod(class, newSelector);
    /* add selector if not exist, implement append with method */
    if (class_addMethod(class,
                        originalSelector,
                        method_getImplementation(swizzledMethod),
                        method_getTypeEncoding(swizzledMethod)) ) {
        /* replace class instance method, added if selector not exist */
        /* for class cluster , it always add new selector here */
        class_replaceMethod(class,
                            newSelector,
                            method_getImplementation(originalMethod),
                            method_getTypeEncoding(originalMethod));

    } else {
        /* swizzleMethod maybe belong to super */
//        method_exchangeImplementations(originalMethod, swizzledMethod);
        class_replaceMethod(class,
                            newSelector,
                            class_replaceMethod(class,
                                                originalSelector,
                                                method_getImplementation(swizzledMethod),
                                                method_getTypeEncoding(swizzledMethod)),
                            method_getTypeEncoding(originalMethod));
    }
}

@end
