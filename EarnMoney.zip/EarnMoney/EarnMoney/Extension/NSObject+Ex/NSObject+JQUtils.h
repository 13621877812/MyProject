//
//  NSObject+JQUtils.h
//  ouyeelf
//
//  Created by mac on 16/3/3.
//
//

#import <Foundation/Foundation.h>

@interface NSObject (JQUtils)
- (BOOL)isValided;
- (BOOL)isNotNSNull;

- (BOOL)isEmpty;
- (BOOL)isNotEmpty;

- (BOOL)isNotEmptyDictionary;
@end
