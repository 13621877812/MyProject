//
//  UIScrollView+EX.m
//  headlineNews
//
//  Created by dengweihao on 2018/1/15.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import "UIScrollView+EX.h"

@implementation UIScrollView (EX)

/**
 UIScorllView 全局配置
 */
+ (void)load {
    //使用系统界面（如文件选择器），界面偏移显示，不建议开启
//    if ([UIDevice currentDevice].systemVersion.floatValue >= 11.0){
//        [[self appearance] setContentInsetAdjustmentBehavior:UIScrollViewContentInsetAdjustmentNever];
//    }
}

@end
