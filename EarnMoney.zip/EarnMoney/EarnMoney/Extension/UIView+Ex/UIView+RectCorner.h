//
//  UIView+RectCorner.h
//  FNBase
//
//  Created by sun on 2018/5/14.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (RectCorner)

- (void)setCornerOnTop:(CGFloat)radius;
- (void)setCornerOnBottom:(CGFloat)radius;
- (void)setAllCorner:(CGFloat)radius;
- (void)setNoneCorner;

@end
