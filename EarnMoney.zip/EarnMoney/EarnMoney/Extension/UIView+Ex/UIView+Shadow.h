//
//  UIView+Shadow.h
//  FNBase
//
//  Created by sun on 2018/5/14.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Shadow)
/**
 * 给View增加阴影.
 *
 * @param shadowOpacity 阴影的透明度（0-1）.
 * @param size 阴影的偏移量 X>0 右侧阴影，y>0底部阴影, <0同理.
 * @param shadowColor 阴影的颜色.
 * @param shadowRadius 阴影的圆角.
 * @param cornerRadius View圆角.
 *
 */
-(void)addShadowWithOpacity:(float)shadowOpacity
               shadowOffset:(CGSize)size
                shadowColor:(UIColor *)shadowColor
               shadowRadius:(CGFloat)shadowRadius
               cornerRadius:(CGFloat)cornerRadius;
@end
