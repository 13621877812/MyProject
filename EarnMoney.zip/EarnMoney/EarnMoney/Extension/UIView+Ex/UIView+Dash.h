//
//  UIView+Dash.h
//  FNBase
//
//  Created by sun on 2018/5/18.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Dash)
/**
 * 给View增加虚线框.
 *
 * @param strokeColor 虚线的颜色.
 * @param fillColor 填充色.
 * @param cornerRadius 虚线圆角.
 * @param lineWidth 虚线的宽度.
 * @param dashPattern 虚线的间隔.
 *
 */
-(void)addDashLineWithStrokeColor:(UIColor *)strokeColor
                        fillColor:(UIColor *)fillColor
                     cornerRadius:(CGFloat)cornerRadius
                        lineWidth:(CGFloat)lineWidth
                  lineDashPattern:(NSArray *)dashPattern;

@end
