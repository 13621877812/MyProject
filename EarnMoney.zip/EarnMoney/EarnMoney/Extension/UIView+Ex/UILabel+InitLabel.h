//
//  UILabel+InitLabel.h
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIColor+HexColor.h"

@interface UILabel (InitLabel)
+ (instancetype)labelWithFontSize:(CGFloat)size textHexColor:(NSString *)hexString;
- (void)setText:(NSString *)text stickerDic:(NSDictionary *)stickerDic stickerSize:(CGSize)stickerSize pattern:(NSString *)pattern;
- (void)addAttributeWithBlock:(NSMutableAttributedString *(^)(NSMutableAttributedString *mutableAttributedString))block;
@end
