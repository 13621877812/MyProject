//
//  UIImageView+ColorImage.m
//  FNBase
//
//  Created by sun on 2018/5/28.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "UIImage+ColorImage.h"

@implementation UIImage (ColorImage)
+ (UIImage *)imageWithImage:(UIImage *)image color:(UIColor *)color
{
    UIGraphicsBeginImageContextWithOptions(image.size, NO, image.scale);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, image.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGContextSetBlendMode(context, kCGBlendModeNormal);
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);
    CGContextClipToMask(context, rect, image.CGImage);
    [color setFill];
    CGContextFillRect(context, rect);
    UIImage*newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;

}
+ (UIImage *)createImageWithColor:(UIColor*)color
{
    CGRect rect = CGRectMake(0.0f,0.0f,30.0f,5.0f);
    UIGraphicsBeginImageContext(rect.size);

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);

    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}


+(UIImage*)grayscaleImageForImage:(UIImage*)image {
    // Adapted from this thread: http://stackoverflow.com/questions/1298867/convert-image-to-grayscale
    const int RED =1;
    const int GREEN =2;
    const int BLUE =3;
    
    // Create image rectangle with current image width/height
    CGRect imageRect = CGRectMake(0,0, image.size.width* image.scale, image.size.height* image.scale);
    
    int width = imageRect.size.width;
    int height = imageRect.size.height;
    
    // the pixels will be painted to this array
    uint32_t *pixels = (uint32_t*) malloc(width * height *sizeof(uint32_t));
    
    // clear the pixels so any transparency is preserved
    memset(pixels,0, width * height *sizeof(uint32_t));
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    // create a context with RGBA pixels
    CGContextRef context = CGBitmapContextCreate(pixels, width, height,8, width *sizeof(uint32_t), colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedLast);
    
    // paint the bitmap to our context which will fill in the pixels array
    CGContextDrawImage(context,CGRectMake(0,0, width, height), [image CGImage]);
    
    for(int y = 0; y < height; y++) {
        for(int x = 0; x < width; x++) {
            uint8_t *rgbaPixel = (uint8_t*) &pixels[y * width + x];
            
            // convert to grayscale using recommended method: http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
            uint32_t gray = 0.3 * rgbaPixel[RED] +0.59 * rgbaPixel[GREEN] +0.11 * rgbaPixel[BLUE];
            
            // set the pixels to gray
            rgbaPixel[RED] = gray;
            rgbaPixel[GREEN] = gray;
            rgbaPixel[BLUE] = gray;
        }
    }
    
    // create a new CGImageRef from our context with the modified pixels
    CGImageRef imageRef = CGBitmapContextCreateImage(context);
    
    // we're done with the context, color space, and pixels
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    free(pixels);
    
    // make a new UIImage to return
    UIImage *resultUIImage = [UIImage imageWithCGImage:imageRef scale:image.scale orientation:UIImageOrientationUp];
    
    // we're done with image now too
    CGImageRelease(imageRef);
    
    return resultUIImage;
}
/** 2018/10/19 add  by sun for fna2018Q40320 start **/
+ (UIImage *)drawImageWithFrame:(CGRect)rect text:(NSString *)text
{
  
  
    CGFloat width = rect.size.width;
    CGFloat height = rect.size.height;
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);

    UIBezierPath *path = [UIBezierPath bezierPath];
    [FNRGBAColor(251, 109, 106, 1) setFill];
    
    //上左右下角
    CGPoint leftTopPoint  = CGPointMake(0, 0);
    CGPoint rightTopPoint  = CGPointMake(width, 0);
  
    //下左右角
    CGPoint leftBottomPoint = CGPointMake(0, height-5);
    CGPoint rightBottomPoint  = CGPointMake(width, height-5);
    
    //下面交叉点
    CGPoint bottomPoint  = CGPointMake(width / 2.0, height);
  
    [path moveToPoint:leftTopPoint];
      //上边框线
    [path addLineToPoint:rightTopPoint];
    [path addLineToPoint:rightBottomPoint];
    [path addLineToPoint:bottomPoint];
    [path addLineToPoint:leftBottomPoint];
    [path addLineToPoint:leftTopPoint];
    
    [path fill];
    
    //把文字嵌入
    [text drawInRect:CGRectMake(3, 3, rect.size.width - 5, 30) withAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont systemFontOfSize:11]}];
    
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    //关闭图形上下文
    UIGraphicsEndImageContext();
   
    return newImage;
}
/** 2018/10/19 add  by sun for fna2018Q40320 end **/


+ (UIImage *)imageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

@end
/**
 
 * Revision History
 
 * -------------------------------------------------------------------------
 
 * Version       Date             Author          Note
 
 * -------------------------------------------------------------------------
 
 * 1.0.0     2018年10月19日        sun         fna2018Q40320
 
 
 */

