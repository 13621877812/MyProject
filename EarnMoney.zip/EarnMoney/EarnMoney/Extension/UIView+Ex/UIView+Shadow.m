//
//  UIView+Shadow.m
//  FNBase
//
//  Created by sun on 2018/5/14.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "UIView+Shadow.h"

@implementation UIView (Shadow)

-(void)addShadowWithOpacity:(float)shadowOpacity
               shadowOffset:(CGSize)size
                shadowColor:(UIColor *)shadowColor
               shadowRadius:(CGFloat)shadowRadius
            cornerRadius:(CGFloat)cornerRadius
{
    //    阴影的透明度
    self.layer.shadowOpacity = shadowOpacity;
    //    阴影的偏移量
    self.layer.shadowOffset = size;
//    阴影的颜色
    self.layer.shadowColor = shadowColor.CGColor;
//    阴影的圆角
    self.layer.shadowRadius = shadowRadius;
    
    //v.layer.masksToBounds=YES;这行去掉
    self.layer.cornerRadius = cornerRadius;
}

@end
