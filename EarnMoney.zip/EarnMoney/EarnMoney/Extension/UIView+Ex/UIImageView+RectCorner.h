//
//  UIImageView+RectCorner.h
//  FNBase
//
//  Created by sun on 2018/5/14.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (RectCorner)

- (UIImageView *)imageWithRoundedCornersSize:(float)cornerRadius;
@end
