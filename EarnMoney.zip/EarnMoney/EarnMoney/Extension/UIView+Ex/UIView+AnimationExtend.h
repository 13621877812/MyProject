//
//  UIView+AnimationExtend.h
//  FNBase
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (AnimationExtend)

- (CABasicAnimation *)rotationAnimation;
- (void)stopRotationAnimation;

@end
