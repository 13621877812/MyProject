//
//  UIScrollView+EX.h
//  headlineNews
//
//  Created by dengweihao on 2018/1/15.
//  Copyright © 2018年 vcyber. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (EX)

@end
