//
//  UIImage+Scale.h
//  HKCommonLib
//
//  Created by sun on 2017/12/28.
//  Copyright © 2017年 Haukit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Scale)

/*
 * 压缩图片到指定大小
 * @param targetSize 目标图片的大小
 * @param sourceImage 源图片
 * @return 目标图片
 */
-(UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize withSourceImage:(UIImage *)sourceImage;


/**
 压缩图片质量

 @param maxLength 最大尺寸
 @return 返回图片的NSData
 */
-(NSData *)compressWithMaxLength:(NSUInteger)maxLength;


@end
