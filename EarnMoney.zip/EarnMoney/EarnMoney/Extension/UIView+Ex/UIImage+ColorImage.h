//
//  UIImageView+ColorImage.h
//  FNBase
//
//  Created by sun on 2018/5/28.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ColorImage)

+ (UIImage *)imageWithImage:(UIImage *)image color:(UIColor *)color;


/**
 颜色转图片

 @param color 颜色
 @return 颜色转成的图片
 */
+ (UIImage *)createImageWithColor:(UIColor *)color;


/**
 图片转成灰色，常用于按钮不可点击时

 @param image 原始图片
 @return 灰色图片
 */
+(UIImage*)grayscaleImageForImage:(UIImage*)image;


/**
 UIImage

 @param rect 图片的大小
 @param text 图片中嵌入的文字
 @return 生成的图片
 */
+ (UIImage *)drawImageWithFrame:(CGRect)rect text:(NSString *)text;
@end
