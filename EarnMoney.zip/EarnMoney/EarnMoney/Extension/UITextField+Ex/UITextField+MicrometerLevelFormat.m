//
//  UITextField+MicrometerLevelFormat.m
//  DKRuntimeLearn
//
//  Created by demoker on 16/3/15.
//  Copyright © 2016年 demoker. All rights reserved.
//

#import "UITextField+MicrometerLevelFormat.h"
#import <objc/runtime.h>
@interface UITextField ()
@end

@implementation UITextField (MicrometerLevelFormat)

static char kTextRange;
static char kPreString;

#pragma mark - method swizzle
- (void)setTextrange:(UITextRange *)textrange{
    objc_setAssociatedObject(self, &kTextRange, textrange, OBJC_ASSOCIATION_COPY);
}
- (UITextRange *)textrange{
   return objc_getAssociatedObject(self, &kTextRange);
}

- (void)setPreString:(NSString *)preString{
    objc_setAssociatedObject(self, &kPreString, preString, OBJC_ASSOCIATION_COPY);
}

- (NSString *)preString{
    return objc_getAssociatedObject(self, &kPreString);
}

#pragma mark - 千分位
//开启千分位模式
- (void)openMicrometerLevelFormat {
    [self addTarget:self action:@selector(reformatAsMicrometerLevel:) forControlEvents:UIControlEventEditingChanged];
//    NSLog(@"++++ = %lu",(unsigned long)[[self allTargets] count]);
    [self configSelectedRange];
}

#pragma mark - private method
//千分位校验
- (void)reformatAsMicrometerLevel:(UITextField *)textField {
    
    NSString *orgStr = [textField.text stringByReplacingOccurrencesOfString:@"," withString:@""];
    BOOL isHaveDian;
    //判断是否有小数点
    if ([orgStr containsString:@"."]) {
        isHaveDian = YES;
    }else{
        isHaveDian = NO;
    }
    NSString *zhStr = [orgStr componentsSeparatedByString:@"."].firstObject;
    NSString *xiaoStr = @"";
    if ([orgStr componentsSeparatedByString:@"."].count > 1) {
        if ([orgStr componentsSeparatedByString:@"."].lastObject.length > 0) {
            xiaoStr = [orgStr componentsSeparatedByString:@"."].lastObject;
        }
    }
    NSNumberFormatter *numberFormatter2 = [[NSNumberFormatter alloc] init];
//    [numberFormatter2 setPositiveFormat:@"#,###.##"];
    numberFormatter2.numberStyle = NSNumberFormatterDecimalStyle;
    NSString *formatStr = [numberFormatter2 stringFromNumber:[NSNumber numberWithDouble:[zhStr doubleValue]]];

    if (isHaveDian) {
        textField.text = [NSString stringWithFormat:@"%@.%@",formatStr,xiaoStr];
    }else{
        if (zhStr.length == 0) {
            textField.text = @"";
        }else{
            textField.text = formatStr;
        }
    }
    
    textField.selectedTextRange = self.textrange;   //保证光标在逗号后时，删除功能正常
    
    NSString * beforeString = self.preString;
    NSString * afterString = textField.text;
    
    NSInteger off ;
    UITextPosition *newPos;
    
    if(beforeString.length - afterString.length == 1){//仅减一个数字
        off = -1;
        newPos = [textField positionFromPosition:self.textrange.start offset:off];
        textField.selectedTextRange = [textField textRangeFromPosition:newPos toPosition:newPos];
    }else if (beforeString.length - afterString.length == 2){//减一个数字  一个逗号
        off = -2;
        newPos = [textField positionFromPosition:self.textrange.start offset:off];
        textField.selectedTextRange = [textField textRangeFromPosition:newPos toPosition:newPos];
    }else if (beforeString.length - afterString.length == -1){//仅加一个数字
        off = 1;
        newPos = [textField positionFromPosition:self.textrange.end offset:off];
        textField.selectedTextRange = [textField textRangeFromPosition:newPos toPosition:newPos];
    }else if (beforeString.length-afterString.length == -2){//加一个数字  一个逗号
        off = 2;
        newPos = [textField positionFromPosition:self.textrange.start offset:off];
        textField.selectedTextRange = [textField textRangeFromPosition:newPos toPosition:newPos];
    }
    
    self.preString = textField.text;//把修改之后的赋值给prestring
}

- (void)configSelectedRange{
    UITextRange *selectedRange = [self selectedTextRange];
    [self textRange:selectedRange];
}
//传回光标的位置
- (void)textRange:(UITextRange *)range {
    self.textrange = range;
}


@end
