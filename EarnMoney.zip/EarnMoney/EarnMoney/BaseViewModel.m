//
//  BaseViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "BaseViewModel.h"

@implementation BaseViewModel
-(id)init
{
    self = [super init];
    if (self) {
        [self initViewModel];
    }
    return self;
}
-(void)initViewModel{}
@end
