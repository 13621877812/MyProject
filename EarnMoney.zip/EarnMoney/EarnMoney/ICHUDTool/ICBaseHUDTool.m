//
//  ICHUDTool.m
//  ICMessageService
//
//  Created by zx on 15-6-24.
//  Copyright (c) 2015年 com.jianq. All rights reserved.
//

#import "ICBaseHUDTool.h"
#import "UIViewExtend.h"
//#import "ICNotificationNames.h"

@implementation ICBaseHUDTool


+ (instancetype) sharedHUDTool
{
    static ICBaseHUDTool *sharedInstance;
    static dispatch_once_t _once_t;
    
    dispatch_once(&_once_t, ^{
        sharedInstance = [[ICBaseHUDTool alloc] init];
    });
    
    return sharedInstance;
}


-(void)addWindowHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay
{
    UIWindow *window = [[[UIApplication sharedApplication]windows]objectAtIndex:0];

    [window addHUDLabelView:labelText Image:image afterDelay:delay];
}

-(void)addWindowHUDActivityView:(NSString*) labelText
{
    UIWindow *window = [[[UIApplication sharedApplication]windows]objectAtIndex:0];
    
    [window addHUDActivityView:labelText];
        
//    [self performSelector:@selector(removeWindowHUDActivityView) withObject:nil afterDelay:2.0];
}

-(void)removeWindowHUDActivityView
{
    UIWindow *window = [[[UIApplication sharedApplication]windows]objectAtIndex:0];
    
    [window removeHUDActivityView];
}

+(void)addWindowHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay
{
    [[ICBaseHUDTool sharedHUDTool]addWindowHUDLabelView:labelText Image:image afterDelay:delay];
}

+(void)addWindowHUDActivityView:(NSString*) labelText
{
    
    
    
    
    [[ICBaseHUDTool sharedHUDTool]addWindowHUDActivityView:labelText];
    
}

+(void)removeWindowHUDActivityView
{
    [[ICBaseHUDTool sharedHUDTool]removeWindowHUDActivityView];
}

-(void)addWindowHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay atView:(UIView *)view{
    
    [view addHUDLabelView:labelText Image:image afterDelay:delay];
}

@end
