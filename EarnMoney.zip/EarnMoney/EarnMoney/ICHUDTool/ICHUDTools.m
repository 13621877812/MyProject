//
//  ICHUDTool.m
//  ICUtils
//
//  Created by jianq on 16/8/29.
//  Copyright © 2016年 com.jianq. All rights reserved.
//

#import "ICHUDTools.h"
#import "UIImage+GIF.h"

@implementation ICHUDTools

+(void)addHUDProgressView
{
    ICHUDView *hudView = [ICHUDView shareHUDView];
    if (hudView != nil) {
        [hudView removeHUDView];
    }
    [hudView addHUDView];
}

+(void)addHUDProgressViewAndDismissAfterDelay:(NSTimeInterval)delay
{
    
}

+(void)removeHUDProgressView
{
    ICHUDView *hudView = [ICHUDView shareHUDView];
    [hudView removeHUDView];
}

@end

@implementation ICHUDView

+ (instancetype)shareHUDView
{
    static ICHUDView *sharedInstance;
    static dispatch_once_t _once_t;
    
    dispatch_once(&_once_t, ^{
        sharedInstance = [[ICHUDView alloc] init];
    });
    
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initUI];
    }
    return self;
}

- (void)initUI
{
    self.frame = [UIScreen mainScreen].bounds;
    self.backgroundColor = [UIColor colorWithRed:((float) 220.0f / 255.0f)
                                           green:((float) 220.0f / 255.0f)
                                            blue:((float) 220.0f / 255.0f)
                                           alpha:0.5f];
    UIImageView *iconImageView= [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 140, 140)];
    iconImageView.image = [UIImage sd_animatedGIFNamed:@"pop_loading_img"];
    iconImageView.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2- 30);
    [self addSubview:iconImageView];
    
    
    UIImageView *loadImageView= [[UIImageView alloc] initWithFrame:CGRectMake(20, 100, 100, 16)];
    loadImageView.image = [UIImage sd_animatedGIFNamed:@"pop_loading_animate"];
    
    [iconImageView addSubview:loadImageView];
}

- (void)addHUDView
{
    UIWindow *window = [[[UIApplication sharedApplication]windows]objectAtIndex:0];
    [window addSubview:[ICHUDView shareHUDView]];
}

- (void)removeHUDView
{
    [self removeFromSuperview];
}

@end
