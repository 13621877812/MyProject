//
//  ICHUDTool.h
//  ICMessageService
//
//  Created by zx on 15-6-24.
//  Copyright (c) 2015年 com.jianq. All rights reserved.
//通用提示框

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ICBaseHUDTool : NSObject

@property (nonatomic, strong)UIActionSheet *actionSheet;
@property (nonatomic, strong)UIAlertView *alertView;

+ (instancetype)sharedHUDTool;

+(void)addWindowHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay;

+(void)addWindowHUDActivityView:(NSString*) labelText;

+(void)removeWindowHUDActivityView;

-(void)addWindowHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay atView:(UIView *)view;

@end
