

#import "UIViewExtend.h"
#import <QuartzCore/QuartzCore.h>

@implementation UIView (Extend)

/**
 @brief:view截图方法
 */
- (UIImage *)captureView:(UIView *)view{
    UIImage *image = nil;
    UIScrollView *scrollView = nil;
    if ([view isKindOfClass:[UIScrollView class]]) {
        scrollView = (UIScrollView *)view;
        CGPoint savedContentOffset = scrollView.contentOffset;
        CGRect savedFrame = scrollView.frame;
        scrollView.contentOffset = CGPointZero;
        scrollView.frame = CGRectMake(0, 0, scrollView.contentSize.width, scrollView.contentSize.height);
        UIGraphicsBeginImageContextWithOptions(scrollView.contentSize, YES, [UIScreen mainScreen].scale);
        CGContextRef contexRef = UIGraphicsGetCurrentContext();
        [scrollView.layer renderInContext: contexRef];
        //清除缓存,解决内存警告
        //        scrollView.layer.contents = nil;
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        scrollView.contentOffset = savedContentOffset;
        scrollView.frame = savedFrame;
    }else{
        UIGraphicsBeginImageContext(view.bounds.size);
        CGContextRef contexRef = UIGraphicsGetCurrentContext();
        [view.layer renderInContext: contexRef];
        //        view.layer.contents = nil;
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    return image;
}


/**
 @功能:在视图上添加菊花
 @参数1:UIActivityIndicatorViewStyle  菊花类型
 @返回值:更改后的图片对象
 */
- (void) addActivityIndicatorView:(UIActivityIndicatorViewStyle) style
{
    UIView *view = [self viewWithTag:ACTIVITYTAG];
    
    if ( nil != view ) {
        [self removeActivityIndicatorView];
    }
    
    UIActivityIndicatorView *aiv = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:style];
    aiv.frame = CGRectMake( (self.frame.size.width - ACTIVITYWIDTH) / 2.0, 
                           (self.frame.size.height - ACTIVITYHRIGHT) / 2.0, 
                           ACTIVITYWIDTH, ACTIVITYHRIGHT);
    aiv.tag = ACTIVITYTAG;
    [aiv startAnimating];
    [self addSubview:aiv];
//    [aiv release];
}

/**
 @功能:删除视图上的菊花
 @返回值:空
 */
- (void) removeActivityIndicatorView
{
    UIView *subView = [self viewWithTag:ACTIVITYTAG];
    [subView removeFromSuperview];
}

/**
 @功能:在视图上添加HUD菊花
 @参数1:UIActivityIndicatorViewStyle  菊花类型
 @返回值:更改后的图片对象
 */
- (void) addHUDActivityView:(NSString*) labelText
{
    UIView *view = [self viewWithTag:HUDTAG];
    
    if ( nil != view ) {
        [self removeHUDActivityView];
    }
    
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self];
    HUD.tag = HUDTAG;
    HUD.labelText = labelText;
    [self addSubview:HUD];
    [HUD show:YES];
//    [HUD release];
}
/**
 @功能:删除视图上的HUD菊花
 @返回值:空
 */
- (void) removeHUDActivityView
{
    UIView *subView = [self viewWithTag:HUDTAG];
    [subView removeFromSuperview];
}

/**
 @功能:在视图上添加HUD菊花
 @参数1:UIActivityIndicatorViewStyle  菊花类型
 @返回值:更改后的图片对象
 */
- (void) addHUDLabelView:(NSString*) labelText Image:(UIImage*) image afterDelay:(NSTimeInterval)delay 
{
    
    UIView *view = [self viewWithTag:HUDLABELTAG];
    
    if ( nil != view ) {
        [view removeHUDActivityView];
    }
    
    MBProgressHUD *HUD = [[MBProgressHUD alloc] initWithView:self];
    HUD.tag = HUDLABELTAG;
    HUD.customView = [[UIImageView alloc] initWithImage:image] ;//autorelease];
    HUD.mode = MBProgressHUDModeCustomView;
    HUD.detailsLabelText = labelText;
    [self addSubview:HUD];
    [HUD show:YES];
    [HUD hide:YES afterDelay:delay];
//    [HUD release];
}

@end
