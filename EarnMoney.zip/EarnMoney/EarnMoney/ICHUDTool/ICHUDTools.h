//
//  ICHUDTool.h
//  ICUtils
//
//  Created by jianq on 16/8/29.
//  Copyright © 2016年 com.jianq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class ICHUDView;

@interface ICHUDTools : NSObject

+(void)addHUDProgressView;

+(void)removeHUDProgressView;

+(void)addHUDProgressViewAndDismissAfterDelay:(NSTimeInterval)delay;

@end

@interface ICHUDView : UIView

+(instancetype)shareHUDView;

- (void)addHUDView;

- (void)removeHUDView;

@end
