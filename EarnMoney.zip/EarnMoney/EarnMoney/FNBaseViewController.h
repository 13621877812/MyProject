//
//  FNBaseViewController.h
//  FNBase
//
//  Created by Eastman on 2018/4/13.
//  Copyright © 2018年 FNCONN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FNBaseViewController : UIViewController

/**
 * 自定义导航View，系统导航栏默认隐藏，可在任意界面修改导航栏颜色而不影响其他页面.
 *
 */
@property (nonatomic, strong) UIView * navgationView;

/**
 * App符合设计风格的背景图片.
 *
 */
@property (nonatomic,strong) UIImageView *backgroundImageView;

/**
 * Add左侧导航按钮.
 *
 * @param 按钮图片名.
 *
 */
- (void)addLeftItemWithImageName:(NSString *)imageName;

/**
 * Add右侧导航按钮.
 *
 * @param 按钮图片名.
 *
 */
- (void)addRightItemWithImageName:(NSString *)imageName;

/**
 * Add左侧导航按钮.
 *
 * @param 按钮文字.
 *
 */
- (void)addLeftItemWithText:(NSString *)text;

/**
 * Add右侧导航按钮.
 *
 * @param 按钮文字.
 *
 */
- (void)addRightItemWithText:(NSString *)text;

/**
 * 左侧导航按钮事件.
 *
 */
- (void)leftItemAction;

/**
 * 右侧导航按钮事件.
 *
 */
- (void)rightItemAction;

@end
