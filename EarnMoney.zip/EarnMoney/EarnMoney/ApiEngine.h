//
//  FNApiEngine.h
//  FNFactoring
//
//  Created by sun  on 2018/4/16.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>

//dev
static NSString *const kBaseUrl = @"http://dev.xinmem.com/profit/appapi/";





//1.第三方授权方式注册和登录
#define loginUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/login"]

//2.发送验证码短信
#define sendSMSUrl @"http://api.smsbao.com/sms?u=ant361&p=AF1E4C106CFBC34099D1C8F8E31A544B&m=13621877812&c=【赚赚】您的验证码为566774"


//3.绑定手机号
#define bindPhoneUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/bindPhone"]

//4.退出登录
#define loginOutUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/loginOut"]


//5.获取用户信息
#define getUserMessageUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/getUserMessage"]

//6.更新用户信息
#define updateUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/update"]

//7.更新用户头像
#define portraitUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/portrait"]

//8.个人中心
#define personalUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/personal"]

//9.我的收藏
#define myCollectUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/myCollect"]


//10.提交意见反馈
#define feedbackAddUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/feedbackAdd"]

//11.系统信息（关于我们等等）
#define getSettingUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/getSetting"]

//12.会员卡列表
#define userCardUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"auser/userCard"]

//13.确认支付
#define wxPayUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"user/wxPay"]


/*                  内容链接                         */


//1、搜索列表
#define getSearchListUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/getSearchList"]

//2、频道列表
#define getChannelListUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/getChannelList"]

//3、焦点图列表
#define getFocusListUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/getFocusList"]

//4、推荐列表
#define recommendListUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/recommendList"]


//5、免费列表
#define freeListUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/freeList"]

//6、某个频道下的内容列表
#define getListByChannelUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/getListByChannel"]


//7、文章详情
#define articleDetailUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"content/articleDetail"]


//8、新增收藏
#define addCollectionUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"collect/add"]

//9、取消收藏
#define delCollectionUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"collect/del"]

//10、点赞
#define addLoveUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"love/add"]

//11、取消点赞
#define delLoveUrl [NSString stringWithFormat:@"%@%@",kBaseUrl,@"love/del"]

