//
//  FNColorDefine.h
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#ifndef FNColorDefine_h
#define FNColorDefine_h


//----------------------颜色类---------------------------
// rgb颜色转换（16进制->10进制）
#define FNColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define FNColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define FNRGBAColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:a]
#define FNRandomColor FNColor(arc4random_uniform(256),arc4random_uniform(256),arc4random_uniform(256))
#define FNWhiteColor [UIColor whiteColor]
#define FNGrayColor(c) FNColor(c,c,c)

#define FN_BackGround_View_Color FNGrayColor(238)

#define FNFontGray153Color FNGrayColor(153)
#define FNFontGray60Color FNGrayColor(60)
#define FNFontGray105Color FNGrayColor(105)
#define FN_MIAN_STYLE_COLOR [UIColor colorWithRed:0.97 green:0.35 blue:0.35 alpha:1.0]
#define FN_VIEV_BG_COLOR [UIColor colorWithRed:0.31 green:0.31 blue:0.31 alpha:1.0f]
#define FNGrayBackgroundColor FNColor(245, 245, 245)

#define FNFontDarkGrayColor FNColor(100,91,77)
#define FNFontLightGrayColor FNGrayColor(52)
#define FNFont204GrayColor FNGrayColor(204)

//TABBAR
#define GoldenColor FNColor(251,115,0)
#define GrayColor FNColor(153,153,153)
#define LightGrayColor FNColor(242,242,242)





#define FNDarkGrayColor FNGrayColor(56)
#define FNLightGrayColor FNGrayColor(238)

#define FNFontGoldenColor FNColor(197,148,63)
#define FNFontLightGoldenColor FNColor(150,114,53)

#define FNSepLineColor FNColor(229,229,229)

#define FNMoreBtnGrayColor FNGrayColor(172)



#endif /* FNColorDefine_h */
