//
//  KirotoPageControl.m
//  YiBaiSong
//
//  Created by kirito_song on 16/4/14.
//  Copyright © 2016年 yibaisong. All rights reserved.
//

#import "KTPageControl.h"
#import "UIImage+ColorImage.h"

@interface KTPageControl()
@property (nonatomic) CGSize size;

@end

@implementation KTPageControl

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.currentImage = [UIImage createImageWithColor:[UIColor redColor]];
        self.defaultImage = [UIImage createImageWithColor:[UIColor whiteColor]];
    }
    return self;
    
}

-(instancetype)initWithFrame:(CGRect)frame currentImage:(UIImage *)currentImage andDefaultImage:(UIImage *)defaultImage {
    
    self = [super initWithFrame:frame];
    self.currentImage = currentImage;
    self.defaultImage = defaultImage;
    return self;
}

-(instancetype) init {
    self = [super init];
    return self;
}


-(void)layoutSubviews
{
    for (int i=0; i<[self.subviews count]; i++) {
        
        UIView* dot = [self.subviews objectAtIndex:i];
        [dot setFrame:CGRectMake(30*i + 5*i, self.size.height/2.0 + 2, 30, 5)];
        dot.layer.cornerRadius = 0;
        dot.clipsToBounds = YES;
    }
}
-(void)setCurrentPage:(NSInteger)page

{
    
    [super setCurrentPage:page];
    

    
}



@end
