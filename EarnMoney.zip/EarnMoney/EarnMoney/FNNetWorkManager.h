//
//  FNNetWorkManager.h
//  FNFactoring
//
//  Created by sun on 2018/4/16.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FNNotificationDefine.h"
#import <AFNetworking/AFNetworking.h>
#import "FNLoginManager.h"

#define FNNetErrorTips @"通讯失败，请稍后再试~"
#define FNNotConnectedToInternet @"请检查您的网络！"

typedef NS_ENUM(NSUInteger,FNResponeseStatus) {
    FNResponeseStatusSuccess = 1,
    FNResponeseStatusFailure,
    FNResponeseStatusAuth,
    FNResponeseStatusCheckPass
};

@class HttpStatus;

@interface FNNetWorkManager : NSObject
    
+ (instancetype)shareManager;
@property (nonatomic,strong) AFHTTPSessionManager *sessionManager;

/**
 *  get请求
 *
 *  @param url     请求地址
 *  @param params  请求参数
 *
 *  当 netError == nil 时 , 网络异常交付failure处理
 *  @param success  请求成功(业务处理成功)
 *  @param failure  请求失败(业务处理失败)
 *  @param netError 请求失败(网络异常)
 */
-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                    progress:(void (^)(NSProgress *uploadProgress))progress
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
                    netError:(void (^)(NSError *error,NSString *message))netError;

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
                    netError:(void (^)(NSError *error,NSString *message))netError;

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                    progress:(void (^)(NSProgress *uploadProgress))progress
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure;

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure;

/**
 *  post请求
 *
 *  @param url     请求地址
 *  @param params  请求参数
 *
 *  当 netError == nil 时 , 网络异常交付failure处理
 *  @param success  请求成功(业务处理成功)
 *  @param failure  请求失败(业务处理失败)
 *  @param netError 请求失败(网络异常)
 */
-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                     progress:(void (^)(NSProgress *uploadProgress))progress
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
                     netError:(void (^)(NSError *error,NSString *message))netError;

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
                     netError:(void (^)(NSError *error,NSString *message))netError;

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                     progress:(void (^)(NSProgress *uploadProgress))progress
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure;

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure;

//+(void)synPost:(NSString *)url params:(NSDictionary *)params success:(void (^)(id responseObject))success failure:(void (^)(id response,NSError *error))failure;


/**
 文件上传
 
 @param url url
 @param params 参数
 @param filePath 文件的URL路径
 @param name 文件名
 @param fileName 在服务器上的名称
 @param mimeType 文件的类型
 @param progress 上传进度
 @param success 上传成功Block
 @param failure 上传失败Block
 @return Task
 */
- (NSURLSessionDataTask *)upLoadFile:(NSString *)url
                               params:(NSDictionary *)params
                          fileUrlPath:(NSString *)filePath
                                 name:(NSString *)name
                             fileName:(NSString *)fileName
                             mimeType:(NSString *)mimeType
                             progress:(void (^)(NSProgress *uploadProgress))progress
                              success:(void (^)(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject))success
                              failure:(void (^)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error))failure;

+(void)reachabilityForInternetConnection;
    
@end

@interface HttpStatus : NSObject

@property (strong,nonatomic) NSString *code;
@property (assign,nonatomic) BOOL success;
@property (strong,nonatomic) NSString *msg;
@property (strong,nonatomic) id data;
@property (assign,nonatomic) NSInteger totalPageCount;
@property (assign,nonatomic) FNResponeseStatus respStatus;

-(NSString *)description;
    
@end
