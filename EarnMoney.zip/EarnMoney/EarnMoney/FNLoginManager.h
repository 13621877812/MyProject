//
//  FNLoginManager.h
//  FNMine
//
//  Created by sun on 2018/4/27.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import <MJExtension/MJExtension.h>
#import "FNNavigationController.h"
#define FNLoginManagerInstance [FNLoginManager shareInstance]
#define FNLoginSuccess FNLoginManagerInstance.loginSuccess

@interface UserInfo : NSObject
@property (nonatomic,copy) NSString *token;
@property (nonatomic,copy) NSString *userId;
@property (nonatomic,copy) NSString *naturalUserId;
@property (nonatomic,copy) NSString *companyName;
@property (nonatomic,copy) NSString *roleName; //角色
//添加指纹登录的字段·
@property(nonatomic,copy)NSString *account;
@property(nonatomic,copy)NSString *passWord;
@property(nonatomic,copy)NSString *secretKey;
@property(nonatomic,copy)NSString *stragly;
@property(nonatomic,assign)BOOL isFingerPrint;//是否开启指纹登录
@property(nonatomic,assign)BOOL isLoginUser; //是否是当前登录的用户
@property(nonatomic,assign)BOOL isRecentlyUser;//是否是最近一次登录的用户
@property(nonatomic,strong)NSData *fingerData; //指纹开启时指纹库信息

@end


@interface FNLoginManager : NSObject

@property (nonatomic,strong) UserInfo *userInfo;
@property (nonatomic,assign,readonly) BOOL loginSuccess;

+(instancetype)shareInstance;

/**
 *  自动登录
 */
-(void)handleAutoLoginAction;

/**
 *  退出登录
 */
-(void)handleLogout:(UIViewController *)viewController;

/**
 *  重新登录
 */
-(FNNavigationController *)handleReLoginAction;


/**
 *  登录成功，处理回调block
 */
-(void)handleLoginReturnBack:(UIViewController *)viewController;

/**
 *  定义登录成功需要回调的block
 */
//-(void)loginRequestReturnBackHandle:(void (^)(id x))block viewController:(UIViewController *)viewController;
-(FNNavigationController *)loginRequestReturnBackHandle:(void (^)(id x))block;

-(UIViewController *)switchAppWindowRootViewController;
-(void)rootLoginViewControllerCancelLogin;

///**
// *  修改注册信息成功，重新登录，并自动设置用户名
// *  修改登录密码时 userName = nil ，则不设置用户名（默认使用上次登录信息）
// */
//-(void)changeUserInfoSuccessThenReLoginWithUserName:(NSString *)userName;

@end
