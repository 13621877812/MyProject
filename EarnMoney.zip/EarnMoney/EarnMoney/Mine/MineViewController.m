//
//  MineViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/21.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "MineViewController.h"
#import "MineCell.h"
@interface MineViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *headView;
@property(nonatomic,strong)NSArray *datas;
@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"个人中心";
    self.view.backgroundColor = LightGrayColor;
    [self.view addSubview:self.tableView];
   
    
    
    // Do any additional setup after loading the view.
}
#pragma - UITableViewDataSource & UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.datas.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *data = self.datas[indexPath.row];
    MineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MineCell"];
    cell.backgroundColor = [UIColor clearColor];
    cell.headImageView.image = [UIImage imageNamed:data[@"icon"]];
    cell.titleLab.text = data[@"title"];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    switch (indexPath.row) {
        case 0:
         
            break;
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
            
            break;
        case 5:
            
            break;
        default:
            break;
    }
    
    
    
}
#pragma mark - getters and setters
-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.tableHeaderView = self.headView;
        _tableView.delegate = self;
        _tableView.dataSource =self;
        [_tableView registerNib:[UINib nibWithNibName:@"MineCell" bundle:nil] forCellReuseIdentifier:@"MineCell"];
    }
    return _tableView;
    
}

-(UIView *)headView
{
    if (_headView == nil) {
        _headView = [UIView new];
        _headView.backgroundColor = [UIColor redColor];
        _headView.frame = CGRectMake(0, 0, FNScreenWidth, 100);
    }
    return _headView;
    
}

-(NSArray *)datas
{
    if (_datas == nil) {
        _datas = @[@{@"icon":@"",@"title":@""},@{@"icon":@"",@"title":@""},
                   @{@"icon":@"",@"title":@""},@{@"icon":@"",@"title":@""}];
    }
    return _datas;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
