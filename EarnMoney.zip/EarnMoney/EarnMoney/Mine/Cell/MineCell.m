//
//  MineCell.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/21.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "MineCell.h"

@implementation MineCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
