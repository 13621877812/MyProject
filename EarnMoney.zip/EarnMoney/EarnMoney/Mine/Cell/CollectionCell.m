//
//  CollectionCell.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/25.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "CollectionCell.h"

@implementation CollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
