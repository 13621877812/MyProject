//
//  RecommendViewModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "BaseViewModel.h"
#import "AboutUsModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface FeedBackViewModel : BaseViewModel

@property(nonatomic,strong)RACCommand *feedBackCommand;

@property(nonatomic,strong)AboutUsModel *model;

@end

NS_ASSUME_NONNULL_END
