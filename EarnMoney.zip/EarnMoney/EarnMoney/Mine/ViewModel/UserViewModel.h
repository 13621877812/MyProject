//
//  RecommendViewModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "BaseViewModel.h"
#import "UserModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface UserViewModel : BaseViewModel

//登录
@property(nonatomic,strong)RACCommand *loginCommand;

//退出
@property(nonatomic,strong)RACCommand *logoutCommand;

@property(nonatomic,strong)UserModel *model;

@end

NS_ASSUME_NONNULL_END
