//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "FeedBackViewModel.h"
@implementation FeedBackViewModel
- (void)initViewModel
{
    self.feedBackCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(NSDictionary *params) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
       
            [[FNNetWorkManager shareManager]post:feedbackAddUrl params:params success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.model = [AboutUsModel mj_objectWithKeyValues:status.data[@"data"]];
                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
   
}
@end
