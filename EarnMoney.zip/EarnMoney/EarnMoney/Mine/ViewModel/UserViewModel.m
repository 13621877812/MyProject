//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "UserViewModel.h"

@implementation UserViewModel
- (void)initViewModel
{
    self.loginCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(NSDictionary *params) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
       
            [[FNNetWorkManager shareManager]post:loginUrl params:params success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.model = [UserModel mj_objectWithKeyValues:status.data[@"data"]];
                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
    self.logoutCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(NSDictionary *params) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
            
            [[FNNetWorkManager shareManager]post:loginOutUrl params:params success:^(HttpStatus *status, NSDictionary *obj) {
                
//                self.model = [UserModel mj_objectWithKeyValues:status.data[@"data"]];
//                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
                
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;
            
            return nil;
        }];
    }];
    
}
@end
