//
//  AboutUsViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "AboutUsViewController.h"
#import "AboutUsViewModel.h"
@interface AboutUsViewController ()

@property(nonatomic,strong)AboutUsViewModel *viewModel;


@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UIWebView *about_usWebView;
@property (weak, nonatomic) IBOutlet UILabel *versionLab;



@end

@implementation AboutUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"关于";
    
    [self bindData];

    [self.viewModel.aboutUsCommand execute:nil];
    
}
-(void)bindData
{
    
    
    //状态动画
    [[[self.viewModel.aboutUsCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.aboutUsCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.logoImageView sd_setImageWithURL:[NSURL URLWithString:self.viewModel.model.app_logo]];
            [self.about_usWebView loadHTMLString:self.viewModel.model.about_us baseURL:nil];
            self.versionLab.text =  self.viewModel.model.app_version;
        }
    }];
    
    
}
#pragma mark - getters and setters
-(AboutUsViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[AboutUsViewModel alloc]init];
    }
    return _viewModel;
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
