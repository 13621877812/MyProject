//
//  FeedBackViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/25.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "FeedBackViewController.h"
#import <QBImagePickerController/QBImagePickerController.h>
#import <IQTextView.h>
#import "FeedBackViewModel.h"
#import "Base64.h"
@interface FeedBackViewController ()<QBImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet IQTextView *adviseTextView;
@property (weak, nonatomic) IBOutlet UIButton *adviseBtn;
@property (weak, nonatomic) IBOutlet UIButton *bugBtn;
@property (weak, nonatomic) IBOutlet UIButton *ideaBtn;

@property (weak, nonatomic) IBOutlet UILabel *numLab;
@property (weak, nonatomic) IBOutlet UITextField *phoneTextField;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@property(nonatomic,strong)FeedBackViewModel *viewModel;
@property(nonatomic,strong)UIButton *selectedBtn;
@end

@implementation FeedBackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self bindData];
}
-(void)initUI
{
    //圆角 边缘颜色
    self.adviseBtn.layer.cornerRadius = 2;
    self.adviseBtn.layer.borderColor = GoldenColor.CGColor;
    self.adviseBtn.clipsToBounds = YES;
    self.bugBtn.layer.cornerRadius = 2;
    self.bugBtn.layer.borderColor = GoldenColor.CGColor;
    self.bugBtn.clipsToBounds = YES;
    self.ideaBtn.layer.cornerRadius = 2;
    self.ideaBtn.layer.borderColor = GoldenColor.CGColor;
    self.ideaBtn.clipsToBounds = YES;
    
    
    //添加事件
    [self.adviseBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.bugBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.ideaBtn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    //默认第一个选择
    self.selectedBtn = self.adviseBtn;
    self.selectedBtn.selected = YES;
    self.selectedBtn.layer.borderWidth = 1;

    
    
    
    
}
-(void)bindData
{
    
    
    //状态动画
    [[[self.viewModel.feedBackCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在反馈..."];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
 
   [[[self.viewModel.feedBackCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
           
        }
    }];
    
    
}
#pragma mark - btnAction
- (IBAction)submitClick:(id)sender {
    
    // type|是|int|1|类型（1功能建议,2bug反馈,3心得）
    // advise|是|string||建议内容
    // image|否|string||图片
    // phone|是|string||联系电话
    NSString *imageBase64 = [UIImageJPEGRepresentation(self.addBtn.imageView.image, 1.0) base64EncodedString];
    NSDictionary *params = @{@"type":@(self.selectedBtn.tag),
                             @"advise":self.adviseTextView.text,
                             @"image":imageBase64,
                             @"phone":self.phoneTextField.text};
    [self.viewModel.feedBackCommand execute:params];
    
    
}
- (IBAction)addImageClick:(id)sender {
    QBImagePickerController *imagePC = [QBImagePickerController new];
    imagePC.delegate = self;
    imagePC.allowsMultipleSelection = YES;
    imagePC.showsNumberOfSelectedAssets = YES;
    imagePC.maximumNumberOfSelection = 1;
    imagePC.mediaType = QBImagePickerMediaTypeImage;
    [self presentViewController:imagePC animated:YES completion:nil];
  
}


-(void)btnClick:(UIButton *)btn
{
    
    btn.selected = YES;
    btn.layer.borderWidth = 1;
   
    self.selectedBtn.selected = NO;
    self.selectedBtn.layer.borderWidth = 0;
    
    self.selectedBtn = btn;
    
    
}
#pragma mark -- QBImagePickerControllerDelegate
- (void)qb_imagePickerController:(QBImagePickerController *)imagePickerController didFinishPickingAssets:(NSArray *)assets {
    //获取图片
    PHAsset *asset = [assets firstObject];
    [[PHImageManager defaultManager] requestImageForAsset:asset targetSize:PHImageManagerMaximumSize contentMode:PHImageContentModeDefault options:nil resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
        
        [self.addBtn setImage:result forState:UIControlStateNormal];

    }];
    
}
#pragma mark - getters and setters
-(FeedBackViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[FeedBackViewModel alloc]init];
    }
    return _viewModel;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
