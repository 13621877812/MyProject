//
//  LoginViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/25.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "LoginViewController.h"
#import "UserViewModel.h"

@interface LoginViewController ()

@property(nonatomic,strong)UserViewModel *viewModel;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self bindData];
}
-(void)bindData
{
    //状态动画
    [[[self.viewModel.loginCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在登录..."];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    
    [[[self.viewModel.loginCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            
        }
    }];
    
    
}
#pragma - btnAction
- (IBAction)loginBtnClick:(id)sender {
    
//    platform|是|int||平台<br>1：微博；2：微信；3：QQ
//    openid|是|string||openid
//    access_token|是|string||access_token
    
    
    [FNNetWorkManager shareManager]post:<#(NSString *)#> params:<#(NSDictionary *)#> success:<#^(HttpStatus *status, NSDictionary *obj)success#> failure:<#^(HttpStatus *status)failure#>
    
    
    
    
    
    
    NSDictionary *params = @{@"platform":@"2",@"openid":@"weeew",@"access_token":@"3454333"};
    [self.viewModel.loginCommand execute:params];
    
    
}
#pragma mark - getters and setters
-(UserViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[UserViewModel alloc]init];
    }
    return _viewModel;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
