//
//  SettingViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "SettingViewController.h"
#import "MineCell.h"
#import "UserViewModel.h"

@interface SettingViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)UIButton *footView;

@property(nonatomic,strong)NSArray *datas;

@property(nonatomic,strong)UserViewModel *viewModel;
@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     self.title = @"设置";
    [self bindData];
    
    
    
}
-(void)bindData
{
    @weakify(self);
    [[self.footView rac_signalForControlEvents:UIControlEventTouchUpInside]subscribeNext:^(__kindof UIControl * _Nullable x) {
        @strongify(self);
        [self.viewModel.logoutCommand execute:nil];
    }];
    
    //
    //状态动画
    [[[self.viewModel.logoutCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.logoutCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
           
        }
    }];
    
    
}
#pragma - UITableViewDataSource & UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.datas.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        return 63;
    }
    
    return 43;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSDictionary *data = self.datas[indexPath.row];
   
    MineCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MineCell"];
    cell.backgroundColor = [UIColor clearColor];
    cell.headImageView.image = [UIImage imageNamed:data[@"icon"]];
    cell.titleLab.text = data[@"title"];
    return cell;
}
#pragma mark - getters and setters
-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.backgroundColor = RGBCOLOR(242, 242, 242);
        _tableView.rowHeight = 43;
        _tableView.tableFooterView = self.footView;
        _tableView.delegate = self;
        _tableView.dataSource =self;
        [_tableView registerNib:[UINib nibWithNibName:@"MineCell" bundle:nil] forCellReuseIdentifier:@"MineCell"];
        [_tableView registerNib:[UINib nibWithNibName:@"CollectionCell" bundle:nil] forCellReuseIdentifier:@"CollectionCell"];
        
    }
    return _tableView;
    
}
-(UIButton *)footView
{
    if (_footView == nil) {
        _footView = [UIButton new];
        _footView.backgroundColor = [UIColor whiteColor];
        _footView.frame = CGRectMake(0, 0, FNScreenWidth, 50);
    }
    return _footView;
    
}
-(NSArray *)datas
{
    if (_datas == nil) {
        _datas = @[@{@"icon":@"",@"title":@"微信登录"},
                   @{@"icon":@"",@"title":@"手机号"},
                   @{@"icon":@"",@"title":@"清理缓存"},
                   @{@"icon":@"",@"title":@"检查更新"}];
    }
    return _datas;
}

-(UserViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[UserViewModel alloc]init];
    }
    return _viewModel;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
