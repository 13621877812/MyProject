//
//  UserModel.h
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserModel : NSObject

@property(nonatomic,copy)NSString *Id;

@property(nonatomic,copy)NSString *image;

@property(nonatomic,copy)NSString *nickname;

@property(nonatomic,copy)NSString *phone;

@property(nonatomic,copy)NSString *intro;

@property(nonatomic,copy)NSString *gender;

@property(nonatomic,copy)NSString *create_time;

@property(nonatomic,copy)NSString *sessionid;

@property(nonatomic,copy)NSString *bindphone;

@end

NS_ASSUME_NONNULL_END
