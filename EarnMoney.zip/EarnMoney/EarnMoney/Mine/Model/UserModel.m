//
//  UserModel.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"Id": @"id"};
}
@end
