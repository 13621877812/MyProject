//
//  AboutUsModel.h
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AboutUsModel : NSObject
@property(nonatomic,copy)NSString *about_us;

@property(nonatomic,copy)NSString *app_logo;

@property(nonatomic,copy)NSString *app_qrcode;

@property(nonatomic,copy)NSString *app_title;

@property(nonatomic,copy)NSString *app_version;

@property(nonatomic,copy)NSString *share_img;

@property(nonatomic,copy)NSString *share_subtitle;

@property(nonatomic,copy)NSString *share_title;

@property(nonatomic,copy)NSString *share_url;

@property(nonatomic,copy)NSString *user_rights;


@end

NS_ASSUME_NONNULL_END
