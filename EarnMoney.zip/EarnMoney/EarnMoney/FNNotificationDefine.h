//
//  FNNotificationDefine.h
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define FNNotificationCenter [NSNotificationCenter defaultCenter]

UIKIT_EXTERN NSString *KLoginSuccessNotification;

UIKIT_EXTERN NSString *KReLoginNotification;

//推送通知名字
UIKIT_EXTERN NSString *MESSAGE_NOTIFACATION_NAME;
