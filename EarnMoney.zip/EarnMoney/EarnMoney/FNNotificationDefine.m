//
//  FNNotificationDefine.m
//  FNFactoring
//
//  Created by sun on 2018/4/13.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNNotificationDefine.h"

NSString *KLoginSuccessNotification = @"FN_KLoginSuccessNotificationt";

NSString *KReLoginNotification = @"FN_KReLoginNotification";

NSString *MESSAGE_NOTIFACATION_NAME = @"com.sun.factoring.message.notifacation.name";
