//
//  FNBaseViewController.m
//  FNBase
//
//  Created by Eastman on 2018/4/13.
//  Copyright © 2018年 FNCONN. All rights reserved.
//

#import "FNBaseViewController.h"

@interface FNBaseViewController ()

@end

@implementation FNBaseViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
//    UIImageView *backgroundImage = [[UIImageView alloc]initWithFrame:self.view.bounds];
//    backgroundImage.image = [UIImage imageNamed:@"common_bgImage"];
//    backgroundImage.userInteractionEnabled = YES;
//    [self.view addSubview:backgroundImage];
//    _backgroundImageView = backgroundImage;
//    

    
//    CGFloat navHeight = isIPhoneX ? 88 : 64;
//    _navgationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ([[UIScreen mainScreen] bounds].size.width), navHeight)];
//    _navgationView.backgroundColor = [UIColor whiteColor];
//    [self.view addSubview:_navgationView];
    
}

#pragma mark 导航栏相关
- (UIBarButtonItem *)createItemWithImageName: (NSString *)imageName Selector:(SEL)selector{
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    imageView.frame = CGRectMake(0, 0, 21, 21);
    imageView.userInteractionEnabled = YES;
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:selector];
    [imageView addGestureRecognizer:tap];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:imageView];
    return item;
}

- (UIBarButtonItem *)createItemWithText: (NSString *)text Selector:(SEL)selector{
    
    UIButton *itemBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [itemBtn setTitle:text forState:UIControlStateNormal];
    [itemBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    itemBtn.titleLabel.font=[UIFont systemFontOfSize:11];
    [itemBtn addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:itemBtn];
  
    return item;
}

- (void)addLeftItemWithImageName:(NSString *)imageName {
    self.navigationItem.leftBarButtonItem = [self createItemWithImageName:imageName Selector:@selector(leftItemAction)];
}
- (void)addRightItemWithImageName:(NSString *)imageName {
    self.navigationItem.rightBarButtonItem = [self createItemWithImageName:imageName Selector:@selector(rightItemAction)];
}

- (void)addLeftItemWithText:(NSString *)text {
    self.navigationItem.leftBarButtonItem = [self createItemWithText:text Selector:@selector(leftItemAction)];
}

- (void)addRightItemWithText:(NSString *)text {
    self.navigationItem.rightBarButtonItem = [self createItemWithText:text Selector:@selector(rightItemAction)];
}

- (void)leftItemAction {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightItemAction {
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

@end
