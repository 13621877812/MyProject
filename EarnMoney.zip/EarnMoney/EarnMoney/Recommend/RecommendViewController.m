//
//  RecommendViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/21.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "RecommendViewController.h"
#import "ChannelModel.h"
#import "RecommendChildViewController.h"
#import "FreeViewController.h"
#import "AudioViewController.h"
@interface RecommendViewController ()<VTMagicViewDelegate, VTMagicViewDataSource>
@property (nonatomic, strong) VTMagicController *magicController;
@property (nonatomic, strong) NSArray *channels;
@property (nonatomic, strong) NSMutableArray *titles;
@property (nonatomic, strong) NSArray *magicViewControllers;
@end

@implementation RecommendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addChildViewController:self.magicController];
   
    [self requestData];
    
}
-(void)requestData
{
    [[FNNetWorkManager shareManager]post:getChannelListUrl params:nil success:^(HttpStatus *status, NSDictionary *obj) {
    
        self.channels = [ChannelModel mj_objectArrayWithKeyValuesArray:status.data[@"data"]];
        for (ChannelModel *model in self.channels) {
            [self.titles addObject:model.name];
        }
        [self.magicController.magicView reloadData];
        NSInteger index = [self.tabBarController.viewControllers indexOfObject:self.navigationController];
        [self.magicController switchToPage:index animated:NO];
        
    } failure:^(HttpStatus *status) {
         NSLog(@"ddd");
    }];
    
    
}

#pragma - VTMagicViewDataSource
- (NSArray<NSString *> *)menuTitlesForMagicView:(VTMagicView *)magicView {
    
    return [self.titles copy];
}

- (UIButton *)magicView:(VTMagicView *)magicView menuItemAtIndex:(NSUInteger)itemIndex {
    static NSString *itemIdentifier = @"repaymentItemIdentifier";
    UIButton *menuItem = [magicView dequeueReusableItemWithIdentifier:itemIdentifier];
    if (!menuItem) {
        menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [menuItem setTitleColor:GoldenColor forState:UIControlStateSelected];
        menuItem.titleLabel.font = [UIFont systemFontOfSize:14.f*FNRelativeScale];
 
    }
    return menuItem;
}

- (UIViewController *)magicView:(VTMagicView *)magicView viewControllerAtPage:(NSUInteger)pageIndex {
    
    ChannelModel *model = self.channels[pageIndex];

    return self.magicViewControllers[pageIndex];
}

#pragma - VTMagicViewDelegate
- (void)magicView:(VTMagicView *)magicView viewDidAppear:(UIViewController *)viewController atPage:(NSUInteger)pageIndex {
    //    打点
}

- (void)magicView:(VTMagicView *)magicView viewDidDisappear:(__kindof UIViewController *)viewController atPage:(NSUInteger)pageIndex {
    //    NSLog(@"index:%ld viewDidDisappear:%@", (long)pageIndex, viewController.view);
}

- (void)magicView:(VTMagicView *)magicView didSelectItemAtIndex:(NSUInteger)itemIndex {
    //    NSLog(@"didSelectItemAtIndex:%ld", (long)itemIndex);
}
#pragma mark - getters and setters
- (VTMagicController *)magicController {
    if (!_magicController) {
        _magicController = [[VTMagicController alloc] init];
        [_magicController.magicView setFrame:CGRectMake(0, self.navgationView.height, FNScreenWidth, FNScreenHeight - self.navgationView.height)];
//        _magicController.magicView.navigationColor = FNGoldenColor;
//        _magicController.magicView.sliderColor = FNSliderSelectGroundColor;
        _magicController.magicView.layoutStyle = VTLayoutStyleCenter;
        _magicController.magicView.switchStyle = VTLayoutStyleDivide;
        _magicController.magicView.navigationHeight = 30.f;
        _magicController.magicView.itemSpacing = 50;
        _magicController.magicView.sliderWidth = 60;
        _magicController.magicView.dataSource = self;
        _magicController.magicView.delegate = self;
        _magicController.magicView.separatorHidden = YES;
       
        [self.view addSubview:_magicController.view];
    }
    return _magicController;
}
-(NSMutableArray *)titles
{
    if (_titles == nil) {
        _titles = [NSMutableArray array];
    }
    return _titles;
}
-(NSArray *)magicViewControllers
{
    if (_magicViewControllers == nil) {
        
        //推荐
        RecommendChildViewController *recommendChildVC = [RecommendChildViewController new];
        
        //是赚钱方法
        FreeViewController *earnVC = [FreeViewController new];
        ChannelModel *model = self.channels[1];
        earnVC.chan_id = model.Id;
        
        //精视频
        FreeViewController *videoVC = [FreeViewController new];
        ChannelModel *videoModel = self.channels[2];
        earnVC.chan_id = videoModel.Id;
        
        //语音专区
        AudioViewController *audioVC = [AudioViewController new];
        ChannelModel *audioModel = self.channels[3];
        audioVC.chan_id = audioModel.Id;
        
        //免费专区
        FreeViewController *freeVC = [FreeViewController new];
 
        
        _magicViewControllers = @[recommendChildVC,earnVC,videoVC,audioVC,freeVC];
        
    }
    
    
    return _magicViewControllers;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
