//
//  FocusModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FocusModel : NSObject

@property(nonatomic,copy)NSString *Id;

@property(nonatomic,copy)NSString *image;

@property(nonatomic,copy)NSString *title;

@property(nonatomic,copy)NSString *url;

@property(nonatomic,copy)NSString *create_time;

@end

NS_ASSUME_NONNULL_END
