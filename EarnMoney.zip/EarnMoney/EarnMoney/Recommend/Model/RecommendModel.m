//
//  RecommendModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "RecommendModel.h"

@implementation RecommendModel
+ (NSDictionary *)mj_objectClassInArray
{
    return @{@"focus":@"FocusModel",
             @"fixed":@"FocusModel",
             @"recom":@"FocusModel",
             @"free":@"FocusModel"
             };
    
}
@end
