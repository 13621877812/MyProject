//
//  ChannelModel.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/21.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "ChannelModel.h"

@implementation ChannelModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"Id": @"id"};
}
@end
