//
//  RecommendModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RecommendModel : NSObject

@property(nonatomic,strong)NSArray *focus;

@property(nonatomic,strong)NSArray *fixed;

@property(nonatomic,strong)NSArray *recom;

@property(nonatomic,strong)NSArray *free;
@end

NS_ASSUME_NONNULL_END
