//
//  DetailModel.h
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ExtendModel : NSObject
@property(nonatomic,copy)NSString *content;

@property(nonatomic,copy)NSString *video_url;

@property(nonatomic,copy)NSString *voice_url;

@end



@interface DetailModel : NSObject

@property(nonatomic,strong)UserModel *user;

@property(nonatomic,strong)ExtendModel *extend;


@property(nonatomic,copy)NSString *Id;

@property(nonatomic,copy)NSString *create_time;

@property(nonatomic,copy)NSString *desc;


@property(nonatomic,copy)NSString *image;

@property(nonatomic,copy)NSString *is_faved;

@property(nonatomic,copy)NSString *is_love;

@property(nonatomic,copy)NSString *loves;

@property(nonatomic,copy)NSString *title;

@property(nonatomic,copy)NSString *type;

@property(nonatomic,copy)NSString *views;

@end

NS_ASSUME_NONNULL_END
