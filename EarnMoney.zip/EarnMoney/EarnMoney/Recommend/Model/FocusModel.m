//
//  FocusModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "FocusModel.h"

@implementation FocusModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"Id": @"id"};
}
@end
