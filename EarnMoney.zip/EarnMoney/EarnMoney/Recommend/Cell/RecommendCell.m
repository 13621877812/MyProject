//
//  RecommendCell.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "RecommendCell.h"

@interface RecommendCell()
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *createTimeLab;
@property (weak, nonatomic) IBOutlet UIImageView *rightImageView;

@end


@implementation RecommendCell
-(void)setModel:(FocusModel *)model
{
    _model = model;
    
    self.titleLab.text = model.title;
    self.createTimeLab.text = model.create_time;
    [self.rightImageView sd_setImageWithURL:[NSURL URLWithString:model.image]];
    self.rightImageView.layer.cornerRadius = 3;
    self.rightImageView.clipsToBounds = YES;
 
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
