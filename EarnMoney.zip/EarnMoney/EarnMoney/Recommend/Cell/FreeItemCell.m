//
//  FreeItemCell.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "FreeItemCell.h"

@interface FreeItemCell()
@property (weak, nonatomic) IBOutlet UIImageView *itemImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@end


@implementation FreeItemCell
-(void)setModel:(FocusModel *)model
{
    _model = model;
    
    self.titleLab.text = model.title;
    self.titleLab.contentMode = UIViewContentModeTop;
    self.titleLab.textColor = [UIColor blackColor];
    [self.itemImageView sd_setImageWithURL:[NSURL URLWithString:model.image]];
    self.itemImageView.layer.cornerRadius = W(5);
    [self.itemImageView setClipsToBounds:YES];
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
