//
//  RecommendChildViewController.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AudioViewController : UIViewController

@property(nonatomic,copy)NSString *chan_id;

@end

NS_ASSUME_NONNULL_END
