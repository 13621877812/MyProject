//
//  SearchViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchViewModel.h"
#import "RecommendCell.h"
#import "FocusModel.h"
#import "HMBannerView.h"
#import "DetailViewController.h"
@interface SearchViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong)SearchViewModel *viewModel;
@property(nonatomic,strong)UITableView *tableView;
@property (nonatomic, strong) UIView *searchView;
@property (nonatomic, strong) UITextField *textField;
@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.titleView = self.searchView;
    [self addRightItemWithText:@"搜索"];
    
    
    [self bindData];
    

    
    
}
-(void)bindData
{
    //搜索
    [[self rac_signalForSelector:@selector(rightItemAction)]
     subscribeNext:^(RACTuple * _Nullable x) {
         self.viewModel.keyword = self.textField.text;
    }];
    [RACObserve(self.viewModel, keyword) subscribeNext:^(id  _Nullable x) {
        [self.viewModel.searchCommand execute:nil];
    }];
    
    
    //状态动画
    [[[self.viewModel.searchCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.searchCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.tableView reloadData];
        }
    }];
  
    
}
#pragma - UITableViewDataSource & UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.viewModel.searchModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    FocusModel *model = self.viewModel.searchModels[indexPath.row];
    RecommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendCell"];
    cell.model = model;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FocusModel *model = self.viewModel.searchModels[indexPath.row];
    DetailViewController *detailVC = [[DetailViewController alloc]init];
    detailVC.model = model;
    [self.navigationController pushViewController:detailVC animated:YES];

}

#pragma mark - getters and setters
-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, FNScreenWidth, FNScreenHeight - FN_TABBER_BAR_HEIGHT-FN_NAVIGATION_BAR_HEIGHT-50) style:UITableViewStylePlain];
        _tableView.rowHeight = 110;
        _tableView.delegate = self;
        _tableView.dataSource =self;
        _tableView.tableFooterView = [UIView new];
        [self.view addSubview:self.tableView];
        [_tableView registerNib:[UINib nibWithNibName:@"RecommendCell" bundle:nil] forCellReuseIdentifier:@"RecommendCell"];
    }
    return _tableView;
    
    
}
-(UIView *)searchView
{
    if (_searchView == nil) {
        _searchView = [UIView new];
        _searchView.frame = CGRectMake(0, 0, 200, 30);
        UITextField *textField = [[UITextField alloc]initWithFrame:
                                  CGRectMake(0, 0, 180, 30)];
        textField.backgroundColor = [UIColor lightGrayColor];
        NSString *placeholder = @"搜索你需要的内容";
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]initWithString:placeholder];
        [attributedString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:10] range:NSMakeRange(0, placeholder.length)];
        textField.attributedPlaceholder = [attributedString copy];
        textField.layer.cornerRadius = 5;
        textField.clipsToBounds = YES;
        self.textField = textField;
        [_searchView addSubview:textField];
        
    }
    
    return _searchView;
    
}

-(SearchViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[SearchViewModel alloc]init];
    }
    return _viewModel;
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
