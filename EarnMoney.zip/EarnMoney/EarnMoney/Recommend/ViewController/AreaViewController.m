//
//  AreaViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/21.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "AreaViewController.h"

@interface AreaViewController ()

@end

@implementation AreaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self requestData];
}
-(void)requestData{
    

    [[FNNetWorkManager shareManager]post:getListByChannelUrl params:@{@"chan_id":self.model.Id,@"page":@"1",@"count":@"10"} success:^(HttpStatus *status, NSDictionary *obj) {
        NSLog(@"SS");
    } failure:^(HttpStatus *status) {
        NSLog(@"SS");
    }];
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
