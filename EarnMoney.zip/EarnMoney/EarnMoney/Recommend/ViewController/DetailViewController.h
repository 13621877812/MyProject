//
//  DetailViewController.h
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FocusModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : UIViewController

@property(nonatomic,strong)FocusModel *model;

@end

NS_ASSUME_NONNULL_END
