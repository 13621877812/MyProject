//
//  VideoViewController.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "FreeViewController.h"
#import "DetailViewController.h"

#import "HMBannerView.h"
#import "FreeViewModel.h"
#import "FreeItemCell.h"
#import "FocusModel.h"
@interface FreeViewController()<UICollectionViewDelegate, UICollectionViewDataSource>
@property(nonatomic,strong)FreeViewModel *viewModel;
@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)UICollectionViewFlowLayout *layout;
@property(nonatomic,strong)HMBannerView *bannerView;


@end

@implementation FreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    
    [self bindData];
    
    if (self.chan_id) {
        [self.viewModel.channelListCommand execute:self.chan_id];
        
    }else
    {
        [self.viewModel.freeCommand execute:nil];
    }
    
   
    
    
    
    
}
-(void)bindData
{
    //状态动画
    [[[self.viewModel.freeCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }];
    [[[self.viewModel.channelListCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }];
    [[[self.viewModel.freeCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.collectionView reloadData];
        }
    }];
    [[[self.viewModel.channelListCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.collectionView reloadData];
        }
    }];
    

}
#pragma - UICollectionViewDelegate & UICollectionViewDataSource
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
   return self.viewModel.freeModel.free.count;
    
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    FocusModel *model = self.viewModel.freeModel.free[indexPath.item];
    
    FreeItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"FreeItemCell" forIndexPath:indexPath];
    cell.model = model;
    
    return cell;

}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{

    FocusModel *model = self.viewModel.freeModel.free[indexPath.item];
    DetailViewController *detailVC = [[DetailViewController alloc]init];
    detailVC.model = model;
    [self.navigationController pushViewController:detailVC animated:YES];
   
    
    
}
#pragma mark - getters and setters
-(UICollectionView *)collectionView
{
    if (_collectionView == nil) {
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, self.bannerView.height, FNScreenWidth, FNScreenHeight - self.bannerView.height - FN_TABBER_BAR_HEIGHT-FN_NAVIGATION_BAR_HEIGHT-50) collectionViewLayout:self.layout];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [self.view addSubview:self.collectionView];
        [_collectionView registerNib:[UINib nibWithNibName:@"FreeItemCell" bundle:nil] forCellWithReuseIdentifier:@"FreeItemCell"];
    }
    return _collectionView;
    
    
}
-(UICollectionViewFlowLayout *)layout
{
    if (_layout == nil) {
        _layout = [[UICollectionViewFlowLayout alloc]init];
        _layout.scrollDirection = UICollectionViewScrollDirectionVertical;
        _layout.minimumInteritemSpacing = W(20);
        _layout.minimumLineSpacing = 10;
        _layout.sectionInset = UIEdgeInsetsMake(0, W(20), 0, W(20));
        _layout.itemSize = CGSizeMake(W(156), W(150));

    }
    return _layout;
    
    
}
-(HMBannerView *)bannerView
{
    if (_bannerView == nil) {
        _bannerView = [[HMBannerView alloc]initWithFrame:CGRectMake(0, 0, FNScreenWidth, W(170)) scrollDirection:ScrollDirectionLandscape images:self.viewModel.freeModel.focus];
        [_bannerView setPageControlStyle:PageStyle_Right];
        _bannerView.rollingDelayTime = 3;
        _bannerView.backgroundColor = [UIColor redColor];
        [self.view addSubview:_bannerView];
        [_bannerView startDownloadImage];
        [_bannerView startRolling];
    }
    return _bannerView;
    
}
-(FreeViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[FreeViewModel alloc]init];
    }
    return _viewModel;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
