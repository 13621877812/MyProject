//
//  VideoViewController.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
typedef NS_ENUM(NSUInteger,STATETYPE) {
   EARN,
   FREE = 1,
   VIDEO = 2
};
NS_ASSUME_NONNULL_BEGIN

@interface FreeViewController : UIViewController


@property(nonatomic,copy)NSString *chan_id;
@end

NS_ASSUME_NONNULL_END
