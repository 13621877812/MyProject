//
//  RecommendChildViewController.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "RecommendChildViewController.h"
#import "DetailViewController.h"
#import "RecommendViewModel.h"
#import "RecommendCell.h"
#import "FocusModel.h"
#import "HMBannerView.h"
@interface RecommendChildViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong)RecommendViewModel *viewModel;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)HMBannerView *bannerView;
@end

@implementation RecommendChildViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
    
    [self bindData];
    
    [self.viewModel.recommendCommand execute:nil];

   
}
-(void)bindData
{
    //状态动画
    [[[self.viewModel.recommendCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
             [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
 
    [[[self.viewModel.recommendCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.tableView reloadData];
        }
    }];
   
    
}
#pragma - UITableViewDataSource & UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.viewModel.recommendModel.recom.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    FocusModel *model = self.viewModel.recommendModel.recom[indexPath.row];
    RecommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendCell"];
    cell.model = model;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FocusModel *model = self.viewModel.recommendModel.recom[indexPath.row];
    DetailViewController *detailVC = [[DetailViewController alloc]init];
    detailVC.model = model;
    [self.navigationController pushViewController:detailVC animated:YES];
    
}
#pragma mark - getters and setters
-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, FNScreenWidth, FNScreenHeight - FN_TABBER_BAR_HEIGHT-FN_NAVIGATION_BAR_HEIGHT-50) style:UITableViewStylePlain];
        _tableView.rowHeight = 110;
        _tableView.tableHeaderView = self.bannerView;
        _tableView.delegate = self;
        _tableView.dataSource =self;
        [self.view addSubview:self.tableView];
        [_tableView registerNib:[UINib nibWithNibName:@"RecommendCell" bundle:nil] forCellReuseIdentifier:@"RecommendCell"];
    }
    return _tableView;
    
    
}
-(HMBannerView *)bannerView
{
    if (_bannerView == nil) {
        _bannerView = [[HMBannerView alloc]initWithFrame:CGRectMake(0, 0, FNScreenWidth, W(170)) scrollDirection:ScrollDirectionLandscape images:self.viewModel.recommendModel.focus];
        [_bannerView setPageControlStyle:PageStyle_Right];
        _bannerView.rollingDelayTime = 3;
        [self.view addSubview:_bannerView];
        [_bannerView startDownloadImage];
        [_bannerView startRolling];
    }
    return _bannerView;
    
}
-(RecommendViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[RecommendViewModel alloc]init];
    }
    return _viewModel;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
