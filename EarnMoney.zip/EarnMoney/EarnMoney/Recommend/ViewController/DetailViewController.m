//
//  DetailViewController.m
//  EarnMoney
//
//  Created by fpm0259 on 2018/12/24.
//  Copyright © 2018年 2015110208. All rights reserved.
//

#import "DetailViewController.h"
#import "DetailViewModel.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UILabel *titleLab;
@property (weak, nonatomic) IBOutlet UILabel *timeLab;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;

@property(nonatomic,strong)DetailViewModel *viewModel;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self bindData];
    self.viewModel.Id = self.model.Id;
    [self.viewModel.detailCommand execute:nil];
    
    // Do any additional setup after loading the view from its nib.
}
-(void)bindData
{
    
    
    //状态动画
    [[[self.viewModel.detailCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.detailCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            self.titleLab.text = self.viewModel.model.title;
            self.timeLab.text = self.viewModel.model.create_time;
            [self.headImageView sd_setImageWithURL:[NSURL URLWithString:self.viewModel.model.image]];
            [self.webView loadHTMLString:self.viewModel.model.extend.content baseURL:nil];
        }
    }];
    
    
    //点赞
    [[[self.viewModel.loveCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在点赞..."];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.loveCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
           
        }
    }];
    
    //收藏
    [[[self.viewModel.collectionCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在收藏..."];
        } else {
            [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
    
    [[[self.viewModel.collectionCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
           
        }
    }];
    
    
    

    
}

- (IBAction)loveClick:(id)sender
{
    [self.viewModel.loveCommand execute:nil];
}
- (IBAction)colllectionClick:(id)sender
{
   [self.viewModel.collectionCommand execute:nil];
}
#pragma mark - getters and setters
-(DetailViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[DetailViewModel alloc]init];
    }
    return _viewModel;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
