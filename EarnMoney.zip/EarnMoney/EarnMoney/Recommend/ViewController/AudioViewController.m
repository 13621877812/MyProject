//
//  RecommendChildViewController.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "AudioViewController.h"
#import "DetailViewController.h"

#import "FreeViewModel.h"
#import "RecommendCell.h"
#import "FocusModel.h"
@interface AudioViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong)FreeViewModel *viewModel;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIView *headView;
@end

@implementation AudioViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self.view addSubview:self.tableView];
    
    
    [self bindData];
    
    [self.viewModel.channelListCommand execute:nil];

   
}
-(void)bindData
{
    //状态动画
    [[[self.viewModel.channelListCommand executing]skip:1]subscribeNext:^(NSNumber * _Nullable x) {
        if ([x boolValue]) {
            [ICBaseHUDTool addWindowHUDActivityView:@"正在加载数据"];
        } else {
             [ICBaseHUDTool removeWindowHUDActivityView];
        }
    }] ;
 
    [[[self.viewModel.channelListCommand executionSignals]switchToLatest] subscribeNext:^(HttpStatus *status) {
        if (status.success) {
            [self.tableView reloadData];
        }
    }];
   
    
}
#pragma - UITableViewDataSource & UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.viewModel.freeModel.free.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    FocusModel *model = self.viewModel.freeModel.free[indexPath.row];
    RecommendCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecommendCell"];
    cell.model = model;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FocusModel *model = self.viewModel.freeModel.free[indexPath.row];
    DetailViewController *detailVC = [[DetailViewController alloc]init];
    detailVC.model = model;
    [self.navigationController pushViewController:detailVC animated:YES];
    
}
#pragma mark - getters and setters
-(UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, FNScreenWidth, FNScreenHeight - FN_TABBER_BAR_HEIGHT-FN_NAVIGATION_BAR_HEIGHT-50) style:UITableViewStylePlain];
        _tableView.rowHeight = 100;
        _tableView.tableHeaderView = self.headView;
        _tableView.delegate = self;
        _tableView.dataSource =self;
        [_tableView registerNib:[UINib nibWithNibName:@"RecommendCell" bundle:nil] forCellReuseIdentifier:@"RecommendCell"];
    }
    return _tableView;
    
    
}
-(UIView *)headView
{
    if (_headView == nil) {
        _headView = [UIView new];
        _headView.backgroundColor = [UIColor redColor];
        _headView.frame = CGRectMake(0, 0, FNScreenWidth, 100);
    }
    return _headView;
    
}
-(FreeViewModel *)viewModel
{
    if (_viewModel == nil) {
        _viewModel = [[FreeViewModel alloc]init];
    }
    return _viewModel;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
