//
//  RecommendViewModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "BaseViewModel.h"
#import "RecommendModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface RecommendViewModel : BaseViewModel

@property(nonatomic,strong)RACCommand *recommendCommand;

//response
@property(nonatomic,strong)RecommendModel *recommendModel;
@end

NS_ASSUME_NONNULL_END
