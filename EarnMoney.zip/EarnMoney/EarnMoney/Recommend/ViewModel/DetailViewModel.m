//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "DetailViewModel.h"
#import "FocusModel.h"
@implementation DetailViewModel
- (void)initViewModel
{

    self.detailCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {

            [[FNNetWorkManager shareManager]post:articleDetailUrl params:@{@"id":self.Id} success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.model = [DetailModel mj_objectWithKeyValues:status.data[@"data"]];
                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
    self.loveCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
            
            NSString *loveUrl = [self.model.is_love isEqualToString:@"0"]?addLoveUrl:delLoveUrl;
            [[FNNetWorkManager shareManager]post:loveUrl params:@{@"cid":self.Id} success:^(HttpStatus *status, NSDictionary *obj) {
                
                self.model = [DetailModel mj_objectWithKeyValues:status.data[@"data"]];
                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
                
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;
            
            return nil;
        }];
    }];
    
    self.collectionCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
            NSString *collectionUrl = [self.model.is_faved isEqualToString:@"0"]?
            addCollectionUrl:delCollectionUrl;
            [[FNNetWorkManager shareManager]post:collectionUrl params:@{@"id":self.Id} success:^(HttpStatus *status, NSDictionary *obj) {
                
                self.model = [DetailModel mj_objectWithKeyValues:status.data[@"data"]];
                status.data = self.model;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
                
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;
            
            return nil;
        }];
    }];
    
    
 
}
@end
