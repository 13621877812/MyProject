//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "RecommendViewModel.h"

@implementation RecommendViewModel
- (void)initViewModel
{
    self.recommendCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {

            [[FNNetWorkManager shareManager]post:recommendListUrl params:nil success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.recommendModel = [RecommendModel mj_objectWithKeyValues:status.data];
                status.data = self.recommendModel;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
    
    
}
@end
