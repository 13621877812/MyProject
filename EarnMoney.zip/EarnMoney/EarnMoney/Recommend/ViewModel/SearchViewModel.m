//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "SearchViewModel.h"
#import "FocusModel.h"
@implementation SearchViewModel
- (void)initViewModel
{
    self.keyword = @"";
    self.searchCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {

            [[FNNetWorkManager shareManager]post:getSearchListUrl params:@{@"keyword":self.keyword} success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.searchModels = [FocusModel mj_objectArrayWithKeyValuesArray:status.data[@"data"]];
                status.data = self.searchModels;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
    
    
   
}
@end
