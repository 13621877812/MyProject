//
//  RecommendViewModel.m
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "FreeViewModel.h"
#import "FocusModel.h"
@implementation FreeViewModel
- (void)initViewModel
{
    self.freeCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {

            [[FNNetWorkManager shareManager]post:freeListUrl params:nil success:^(HttpStatus *status, NSDictionary *obj) {
               
                self.freeModel = [RecommendModel mj_objectWithKeyValues:status.data];
                status.data = self.freeModel;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
 
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;

            return nil;
        }];
    }];
    
    self.channelListCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(NSString * chan_id) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
            NSLog(@"%@",getListByChannelUrl);
            [[FNNetWorkManager shareManager]post:getListByChannelUrl params:@{@"chan_id":@"158"} success:^(HttpStatus *status, NSDictionary *obj) {
           
                NSMutableArray *focusModels = [FocusModel mj_objectArrayWithKeyValuesArray:status.data[@"focus"]];
                NSMutableArray *data = [FocusModel mj_objectArrayWithKeyValuesArray:status.data[@"data"]];
                self.freeModel = [RecommendModel new];
                self.freeModel.focus = focusModels;
                self.freeModel.free = data;
                status.data = self.freeModel;
                [subscriber sendNext:status];
                [subscriber sendCompleted];
                
            } failure:^(HttpStatus *status) {
                [subscriber sendNext:status];
                [subscriber sendCompleted];
            }] ;
            
            return nil;
        }];
    }];
    
   
}
@end
