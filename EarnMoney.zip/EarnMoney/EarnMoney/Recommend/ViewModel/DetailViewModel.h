//
//  RecommendViewModel.h
//  EarnMoney
//
//  Created by sun on 2018/12/22.
//  Copyright © 2018 2015110208. All rights reserved.
//

#import "BaseViewModel.h"
#import "DetailModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface DetailViewModel : BaseViewModel

@property(nonatomic,strong)RACCommand *detailCommand;

//request
@property(nonatomic,copy)NSString *Id;


//response
@property(nonatomic,strong)DetailModel *model;



@property(nonatomic,strong)RACCommand *loveCommand;

@property(nonatomic,strong)RACCommand *collectionCommand;
@end

NS_ASSUME_NONNULL_END
