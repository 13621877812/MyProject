//
//  FNNetWorkManager.m
//  FNFactoring
//
//  Created by sun on 2018/4/16.
//  Copyright © 2018年 sun. All rights reserved.
//

#import "FNNetWorkManager.h"
typedef NS_ENUM(NSUInteger, FNHTTPClientRequestType) {
    FNHTTPClientRequestTypeGET = 0,
    FNHTTPClientRequestTypePOST,
};

@implementation FNNetWorkManager

+ (instancetype)shareManager
{
    static id manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc] init];
    });
    return manager;
}

- (AFHTTPSessionManager *)sessionManager
{
    if(!_sessionManager){
        _sessionManager = [[AFHTTPSessionManager alloc] init];
        AFJSONResponseSerializer *serializer = [AFJSONResponseSerializer serializer];

        serializer.removesKeysWithNullValues = YES;
        _sessionManager.responseSerializer = serializer;
        _sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json", @"text/javascript",@"text/html",@"text/plain",nil];
        _sessionManager.requestSerializer = [AFJSONRequestSerializer serializer];
        [_sessionManager.requestSerializer willChangeValueForKey:@"timeoutInterval"];
#ifdef DEBUG
        _sessionManager.requestSerializer.timeoutInterval = 120;
#else
        _sessionManager.requestSerializer.timeoutInterval = 8;
#endif
        [_sessionManager.requestSerializer didChangeValueForKey:@"timeoutInterval"];
        [_sessionManager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    }
    return _sessionManager;
}
    

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                    progress:(void (^)(NSProgress *uploadProgress))progress
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
                    netError:(void (^)(NSError *error,NSString *message))netError;
{
    return [self asynRequestAtPort:url method:FNHTTPClientRequestTypeGET params:params progress:progress success:success failure:failure netError:netError];
}


-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
                    netError:(void (^)(NSError *error,NSString *message))netError
{
    return [self get:url params:params progress:nil success:success failure:failure netError:netError];
}

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                    progress:(void (^)(NSProgress *uploadProgress))progress
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
{
    return [self get:url params:params progress:progress success:success failure:failure netError:nil];
}

-(NSURLSessionDataTask *)get:(NSString *)url
                      params:(NSDictionary *)params
                     success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                     failure:(void (^)(HttpStatus* status))failure
{
    return [self get:url params:params progress:nil success:success failure:failure netError:nil];
}

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                     progress:(void (^)(NSProgress *uploadProgress))progress
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
                     netError:(void (^)(NSError *error,NSString *message))netError;
{
    return [self asynRequestAtPort:url method:FNHTTPClientRequestTypePOST params:params progress:progress success:success failure:failure netError:netError];
}

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
                     netError:(void (^)(NSError *error,NSString *message))netError
{
    return [self post:url params:params progress:nil success:success failure:failure netError:netError];
}

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                     progress:(void (^)(NSProgress *uploadProgress))progress
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
{
    return [self post:url params:params progress:progress success:success failure:failure netError:nil];
}

-(NSURLSessionDataTask *)post:(NSString *)url
                       params:(NSDictionary *)params
                      success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                      failure:(void (^)(HttpStatus* status))failure
{
    return [self post:url params:params progress:nil success:success failure:failure netError:nil];
}


#pragma mark --- private
/**
 *  当 netError == nil 时 , 网络异常交付failure处理
 *
 *  @param success  请求成功(业务处理成功)
 *  @param failure  请求失败(业务处理失败)
 *  @param netError 请求失败(网络异常)
 */
-(NSURLSessionDataTask *)asynRequestAtPort:(NSString *)url
                                    method:(FNHTTPClientRequestType)type
                                    params:(NSDictionary *)params
                                  progress:(void (^)(NSProgress *uploadProgress))progress
                                   success:(void (^)(HttpStatus* status,NSDictionary* obj))success
                                   failure:(void (^)(HttpStatus* status))failure
                                  netError:(void (^)(NSError *error,NSString *message))netError;
{

    
    AFHTTPSessionManager * manager = self.sessionManager;
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    
    //拼接系统参数
    // 发送请求
    switch (type) {
        case FNHTTPClientRequestTypeGET:{
           
            return [manager GET:url parameters:params progress:^(NSProgress * _Nonnull downloadProgress) {
                if (progress) {
                    progress(downloadProgress);
                }
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
               [self requestFinishedWithSuccess:success failure:failure task:task response:responseObject];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [self requestFinishedWithFailure:failure netError:netError task:task error:error];
                NSHTTPURLResponse *response = (NSHTTPURLResponse*)task.response;
                NSInteger statusCode = response.statusCode;
//                //服务器返回的业务逻辑报文信息
               NSString* errResponse = [[NSString alloc] initWithData:(NSData *)error.userInfo[AFNetworkingOperationFailingURLResponseDataErrorKey] encoding:NSUTF8StringEncoding];
                NSLog(@"%@",errResponse);
                NSLog(@"error ==%@", [error userInfo][@"com.alamofire.serialization.response.error.string"]);
                if ([error userInfo][@"com.alamofire.serialization.response.error.data"]) {
                    NSLog(@"error:%@",[NSJSONSerialization JSONObjectWithData:([error userInfo][@"com.alamofire.serialization.response.error.data"]) options:NSJSONReadingMutableLeaves error:NULL]);
                }
            }];
            
            break;
        }
        case FNHTTPClientRequestTypePOST:{          //post请求
            return [manager POST:url parameters:params progress:^(NSProgress * _Nonnull uploadProgress) {
                if (progress) {
                    progress(uploadProgress);
                }
            } success:^(NSURLSessionDataTask * _Nonnull task, NSMutableDictionary *  _Nullable responseObject) {
                NSLog(@"url:%@---params:%@----res:%@",url,params,responseObject);
               [self requestFinishedWithSuccess:success failure:failure task:task response:responseObject];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                [self requestFinishedWithFailure:failure netError:netError task:task error:error];
            }];
            
            break;
        }
        
        default:
        break;
    }
}



-(void)requestFinishedWithSuccess:(void (^)(HttpStatus* status,NSDictionary* obj))success failure:(void (^)(HttpStatus* status))failure task:(NSURLSessionDataTask * _Nonnull )task response:(id  _Nullable)responseObject
{
    HttpStatus* status = [HttpStatus new];
 
    
    responseObject = [responseObject mutableCopy];
    
    if (responseObject != nil) {
        status.totalPageCount = responseObject[@"totalPageCount"] ? [responseObject[@"totalPageCount"] integerValue] : (NSInteger)0;
        status.code = [NSString stringWithFormat:@"%@",responseObject[@"error_code"]];
        status.success = [status.code isEqualToString:@"0"];
        status.msg = responseObject[@"error_msg"];
       
       if ([responseObject isEqual:[NSNull null]]) {
                status.data = @{};
            }else{
                status.data = responseObject;
            }
        
      
        if(status.success){
            success(status,responseObject);
        }else{
            if ([status.code isEqualToString:@"100000010"]) {    //重新登录

                [FNLoginManagerInstance handleReLoginAction];
                responseObject[@"msg"] = @"请重新登录";
                status.msg = @"请重新登录";
            }
            
            status.data = responseObject;
            failure(status);
        }
    }else{
        NSLog(FNNetErrorTips);  //HUD提示网络异常
        status.msg = FNNetErrorTips;
        failure(status);
    }
    
}

-(void)requestFinishedWithFailure:(void (^)(HttpStatus* status))failure netError:(void (^)(NSError *error,NSString *message))netError task:(NSURLSessionDataTask * _Nonnull )task error:(NSError * _Nonnull)error
{
    NSLog(@"%@",error.description);  //网络异常
    
    if (netError) {
        NSString *msg;
        if (error.code == NSURLErrorNotConnectedToInternet) {
            msg = FNNotConnectedToInternet;
        }else{
            msg = FNNetErrorTips;
        }
        netError(error,msg);
        return;
    }

//    *  当 netError == nil 时 , 网络异常交付failure处理
    HttpStatus* status = [HttpStatus new];
    status.code = [NSString stringWithFormat:@"%ld",(long)error.code];
    status.data = @{};
    if (error.code == NSURLErrorNotConnectedToInternet) {
        status.msg = FNNotConnectedToInternet;
    }else{
        status.msg = FNNetErrorTips;
    }
    failure(status);
}
    
//-(AFSecurityPolicy *)customSecurityPolice
//{
//    NSString *path = [[NSBundle mainBundle]pathForResource:@"fn.com.cn" ofType:@"cer"];
//
//    NSData *certData = [NSData dataWithContentsOfFile:path];
//
//    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
//    [securityPolicy setAllowInvalidCertificates:YES];
//    [securityPolicy setValidatesDomainName:NO];
//    NSSet *set = [NSSet setWithArray:@[certData]];
//    [securityPolicy setPinnedCertificates:set];
//
//    return securityPolicy;
//}

/**
 文件上传
 
 @param url url
 @param params 参数
 @param filePath 文件的URL路径
 @param name 文件名
 @param fileName 在服务器上的名称
 @param mimeType 文件的类型
 @param progress 上传进度
 @param success 上传成功Block
 @param failure 上传失败Block
 @return Task
 */
- (NSURLSessionDataTask *)upLoadFile:(NSString *)url
                               params:(NSDictionary *)params
                          fileUrlPath:(NSString *)filePath
                                 name:(NSString *)name
                             fileName:(NSString *)fileName
                             mimeType:(NSString *)mimeType
                             progress:(void (^)(NSProgress *uploadProgress))progress
                              success:(void (^)(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject))success
                              failure:(void (^)(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error))failure
{
    AFHTTPSessionManager * manager = self.sessionManager;
    return [manager POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        //        [formData appendPartWithFileURL:[NSURL fileURLWithPath:@"/Users/User/Desktop/屏幕快照.png"]
        //                                   name:@"file" fileName:@"123.png" mimeType:@"image/png" error:nil];
        [formData appendPartWithFileURL:[NSURL fileURLWithPath:filePath]
                                   name:name
                               fileName:fileName
                               mimeType:mimeType
                                  error:nil];
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        progress(uploadProgress);
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(task,responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(task,error);
    }];
}



+(void)reachabilityForInternetConnection
{
    // 1.获得网络监控的管理者
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    
    // 2.设置网络状态改变后的处理
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        // 当网络状态改变了, 就会调用这个block
        switch (status) {
            case AFNetworkReachabilityStatusUnknown: // 未知网络
            NSLog(@"未知网络");
            break;
            
            case AFNetworkReachabilityStatusNotReachable: // 没有网络(断网)
//            [MBProgressHUD showError:FNNotConnectedToInternet];
            NSLog(FNNotConnectedToInternet);
            break;
            
            case AFNetworkReachabilityStatusReachableViaWWAN: // 手机自带网络
            NSLog(@"手机自带网络");
            break;
            
            case AFNetworkReachabilityStatusReachableViaWiFi: // WIFI
            NSLog(@"WIFI");
            break;
        }
    }];
    
    // 3.开始监控
    [mgr startMonitoring];
}

@end

@implementation HttpStatus
-(NSString *)description
{
    return [NSString stringWithFormat:@"{code:%@,\nsuccess:%@,\nmsg:%@,\ntotalPageCount:%ld,\ndata:%@}",_code,@(_success),_msg,(long)_totalPageCount,_data];
}
@end
/**
 
 * Revision History
 
 * -------------------------------------------------------------------------
 
 * Version       Date             Author          Note
 
 * -------------------------------------------------------------------------
 
 * 1.0.0     2018年7月26日                sun         modify
 
 */

